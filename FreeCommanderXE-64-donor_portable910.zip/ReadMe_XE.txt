﻿================================================================================
WHAT IS FreeCommander
================================================================================
FreeCommander is an easy-to-use alternative to the standard Windows file manager. 
You can configure almost everything. Supported Windows versions: Windows XP and above.
FreeCommander XE is in two versions 32 and 64 bit. 
Please check the info about using FreeCommander XE 32 bit on 64 bit Windows http://freecommander.com/en/version-summary/    



================================================================================
AFTER YOU HAVE INSTALLED FreeCommander XE
================================================================================

If you have worked with the FreeCommander 2009.02b:
- the settings of the FreeCommander 2009.02b are not compatible with the settings of the FreeCommander XE
- do not copy the old settings to the new settings folder

If you have worked with the FreeCommander XE 32 bit version and now you want use 64 bit version
- the settings are compatible; you can use the settings from the 32 bit version in the 64 bit version
- for moving the settings you can use Tools->Backup all settings, Tools->Restore all settings


The available help files you can download from the site http://freecommander.com/en/languages/  

Trouble with the help file
==========================
When viewing your CHM documentation, Microsoft's HTML Help Viewer is showing an error page saying either that:
 - The action has been canceled 
 - The page cannot be displayed
 
Solutions
 - Launch help file from local drive and not from a network path or via a mapped networked drive.  
 - Make sure your help file isn't in a path with symbols such as "#" (sharp).  
 - In some cases, you can have access to an "unblock" button in the properties page of the help file. Right click on the file then go to its properties and click the "unblock" button. This button is not available in all systems though. 
 - Try the HHReg utility http://www.ec-software.com/products_hhreg.html or read this technical note from the Microsoft Knowledge Base http://support.microsoft.com/kb/896054/.

================================================================================
FEEDBACK & SUGGESTIONS
================================================================================

Direct your feedback, suggestions and bug reports to the FreeCommander forum http://www.forum.freecommander.com
or directly to me marek@freecommander.com but please do not expect that you get an answer immediately :). 


I hope you will enjoy FreeCommander 

MAREK JASINSKI

================================================================================
Important changes and bug fixes in the release 910
================================================================================
- Bug fix: Tab sorting does not work as expected


================================================================================
Important changes and bug fixes in the release 909
================================================================================
- Bug fix: Lock toolbar does not work if action toolbar and favorite toolbar are locked in one step https://freecommander.com/forum/viewtopic.php?p=42869#p42869
- Bug fix: Some texts in internal PDF viewer are in German
- Bug fix: After using F10 (Dual/one panel), command "Customize toolbar" from context menu of the address bar does not work  
- Implemented: Search files/folders dialog - "Accessed" column added
- Implemented: New actions added - "Sort tabs in ascending order", "Sort tabs in descending order"  
- Implemented: Settings->Folder tabs - "Use for sorting" options added
- Implemented: Save tab groups dialog improved - "Use left/right panel" option added
- Implemented: Multi rename dialog - shortcut Ctrl+E defined for "Rename using text editor..."
- Implemented: Copy speed and time remaining is shown in copy dialog for "Use FreeCommander" method  
- Implemented: Settings->File/folder list->Mouse shortcuts - for right mouse button new action is possible "Focus item - thumbnails view"
- Changed: Edit->Save selection to file - file extension changed from *.sel to *.fcsel; Double clicking on *.fcsel will perform the action “Edit->Restore Selection from File”.


================================================================================
Important changes and bug fixes in the release 908
================================================================================
- Bug fix: The display of the selected items count in the status bar may be incorrect https://freecommander.com/forum/viewtopic.php?p=42834#p42834
- Bug fix: Tab group may load not properly https://freecommander.com/forum/viewtopic.php?p=42848#p42848
- Bug fix: Quick filter is activated unnecessarily  https://freecommander.com/forum/viewtopic.php?t=13827


================================================================================
Important changes and bug fixes in the release 907
================================================================================
- Bug fix: It is possible that the program cannot start (due to an exception) after closing if the tree splitter was in a certain position when closing.
- Bug fix: Exception on saving settings  for quick filter - if only one panel is visible
  
- Implemented: Saving and loading tab groups is possible (View->Tab groups)  


================================================================================
Important changes and bug fixes in the release 906
================================================================================
- Bug fix: Save selection, Restore selection, Save selection to file, Restore selection from file - does not work properly for plain view
- Bug fix: Focused item is not always visible if go to parent folder is performed
- Bug fix: Auto refresh may not work if copy/move/delete is performed with Android folders
- Bug fix: Create folder with F7 is broken if subfolder is used e.g. "folder1\folder2"
- Bug fix: Long text in the message box maybe truncated if one of the color schemes is used: FreeCommander_Dark, FreeCommander_DarkBlue, FreeCommander_Light, FreeCommander_Solarized
- Bug fix  The auto-selectable view may not be found for "This PC".   

- Implemented: Search dialog - encoding 'Unicode (UTF-16LE)', 'Unicode (UTF-16BE)' added 

================================================================================
Important changes and bug fixes in the release 905
================================================================================
- Bug fix: Favorite tree - flicker on refresh 
- Bug fix: Thumbnails are not displayed when "Plain view - files" and "Show only files (no folders)" are active
- Bug fix: Freecommander.exe may disappear when plugging/unplugging some USB devices
- Bug fix: "Switch locked folder to current" is broken
- Bug fix: Focused item is not always visible if view is changed back to parent folder  
- Changed: Better performance for copy/move operation defined as "Use FreeCommander" and copy method "Use Windows..."
- Implemented: Free area context menu - added items "History back", "History next" 
- Implemented: New option for tabs - Show close button on all tabs
- Implemented: The queue dialog size and position is saved now
- Implemented: Copy, move and delete dialogs - size and position are saved now
- Implemented: Search duplicates - new items added for "Duplicates selection":  "Mark all with the path pattern...", "Unmark all with the path pattern..."


================================================================================
Important changes and bug fixes in the release 904
================================================================================

- Bug fix: Favorite folders tree - after adding new item or removing item all tree items disappeared (rarely happens)
- Bug fix: Exception possible on activate or deactivate settings dialog from the taskbar (after opening first the viewer settings in the settings dialog)
- Bug fix: Folder tree - font color is wrong (introduced in 903)
- Bug fix: Tree panel position after switching from one to dual panel maybe wrong (if option tree per panel is used)
- Bug fix: Thumbnails - option "Show only files" does not work if switch from non thumbnails view to thumbnails
- Bug fix: Replacing existing files during the synchronization is slow  https://freecommander.com/forum/viewtopic.php?p=42464#p42464
- Bug fix: Compute Checksums "Copy to clipboard" button does not work for lines where the sum is not equal with the pattern sum
- Bug fix: Image viewer - options "Fit to window" and "Original size" does not work properly
- Bug fix: Tree refresh problems   https://freecommander.com/forum/viewtopic.php?p=42563#p42563
- Bug fix: Changing the color of the font in the title bar of the file list is not possible (color is saved in the color scheme .colors file)  https://freecommander.com/forum/viewtopic.php?p=42578#p42578
- Bug fix: Mouse shortcut - rename on ".." item does not open multirename
- Changed: Tab properties - if changing of the locked path in active tab the file list in the tab is reloaded with the new locked path https://freecommander.com/forum/viewtopic.php?t=13736
- Changed: Toolbar customizer - in the Description column show only description
- Implemented: Multi rename - option for definig of the timestamp format for exiftool in FreeCommander.mren.ini: ExifToolTimestampFormat 
- Implemented: zst archive for Total7Zip (with Modern7z  https://www.tc4shell.com/en/7zip/modern7z/)   
- Implemented: New action added - Sort by created date
- Implemented: Quick operations options have been expanded
- Implemented: New actions for quick operations added: "Perform quick copy...", "Perform quick move", "Quick operation - set target path..." 


================================================================================
Important changes and bug fixes in the release 903
================================================================================
   
- Bug fix: Click on tab does not activate the site  https://freecommander.com/forum/viewtopic.php?t=13723
- Bug fix: Windows 11, Option "Show popup menu for left button drop" is broken
- Bug fix: "Tools->Toggle font size" raise exception if menu is defined as toolbar
- Bug fix: Multirename with exiftool is broken
- Bug fix: Viewer settings - saving EXIF tags per file extension does not work if tags field is empty 

- Changed: It is possible now to define alternative status text in the FreeCommander.onedrive.ini. Example: 3=Keep on this device|Always available on this device
  
- Implemented: Create folder F7 from full path (c:\aa\ab) is possible now
- Implemented: Using of the built-in icons is now possible for action toolbar, favorite toolbar and tabs
- Implemented: Quick operations (quick copy, quick move) are possible; Settings for quick operations: "Tools->Settings->File/folder operations: Quick operations"   


================================================================================
Important changes and bug fixes in the release 900
================================================================================
   
- Bug fix: Help does not open if using menu Help->Contents
- Bug fix: Losing all shortcuts after invoking Quick Filter https://freecommander.com/forum/viewtopic.php?p=42197#p42197
- Bug fix: Tab Properties dialog - "Remove all colors" is broken
- Bug fix: "Remove selected element from the container" does not work for folder items  https://freecommander.com/forum/viewtopic.php?p=42212#p42212
- Bug fix: "Use Windows delete method" option in delete dialog can be automaticaly deactivated but is not reactivated    
- Bug fix: Password input for fcZip plugin allow strings longer as 25 but maximal length of password is 25

================================================================================
Important changes and bug fixes in the release 899
================================================================================
   
- Bug fix: Help view does not work properly when the following color schemes are used  FreeCommander_Dark, FreeCommander_Dark_Blue, FreeCommander_Solarized, FreeCommander_Light 
- Bug fix: File list reload with Ctrl+R may be broken - the scroll position is not the same
- Bug fix: Auto refresh is broken if the delete dialog was closed with ESC (without starting deletion)

- Implemented: New options for "Tab Management" added. Function "Last used tab (Ctrl+PgUp)" is configurable with: "Only tabs from active pane" and "Show quick filter for list filtering" 
- Implemented: New option "Use recycle bin when overwriting" in the FreeCommander copy dialog (Settings tab) 


================================================================================
Important changes and bug fixes in the release 898
================================================================================
   
- Bug fix: Quick starter items with assigned color can not be started/opened
- Bug fix: Using of the "favorite folder open" changes the tree when the setting FollowExternalAddressChanges is not set
- Bug fix: Open focused folder in other pane - does not work if parent folder (..) is focused
- Bug fix: Qucik starter - tooltip of the quick filter field is cut
- Bug fix: Secondary shortcut is active if focus is in Quick Filter field

- Implemented: New option in the freecommander.ini "AlwaysLoadFileAllocatedMemorySize=0"; setting this option to 1 may slowdown loading the files 
- Implemented: Shortcuts added for "increase thumbnail size" (Shift++) and "decrease thumbnail size" (Shift+-)
- Implemented: New action added actEditNcSelection; Setting of the "NC-Mode (Sticky selection)"
 
- Changed: Rename operation - if target file already exists, it is possible now to delete the existing file
 
================================================================================
Important changes and bug fixes in the release 897
================================================================================
   
- Bug fix: Tree per panel - on start selected node maybe not visible  
- Bug fix: Quick starter - items font color are gone after adding new item or removing item 
- Bug fix: The tooltip view in the file list is broken

- Implemented: Attributes/Timestamp dialog - button "Show errors only" added 
- Implemented: New actions added - "Increase thumbnail size", "Decrease thumbnail size", "Show popup menu for thumbnails"
- Implemented: Open layout actions - overlay numbers added (up to 20)
- Implemented: Quick filter - use "\;" for filter ";" in the file name
- Implemented: Folder synchronize - in exclude folder filter you can use now the path, e.g. d:\images, *\images 

- Changed: Quick starter shortcut for "Item colors" changed from Ctrl+L to Alt+F

================================================================================
Important changes and bug fixes in the release 896
================================================================================
   
- Bug fix: Exception on open empty quick starter repository  
- Bug fix: Several problems on displaying the drive bar


================================================================================
Important changes and bug fixes in the release 895
================================================================================
   
- Bug fix: Char "|" can not be shown in hints  
- Bug fix: Viewer - Action "Save - overwrite without confirmation" is broken
- Bug fix: Column sorting symbol is not refreshed if using shortcut Ctrl+F3, Ctrl+F4,... for sorting change
- Buf fix: Copy/move/pack dialog - quick filter does not work if "NOT" operator (\~) is used 

- Implemented: New command "Toggle selection" added - toggles between defined selection modes: Select all files, Select all Items, Deselect all
- Implemented: Font size for functions bar can be defined now
- Implemented: Favorite tools - custom icon is now possible https://freecommander.com/forum/viewtopic.php?p=41736#p41736
- Implemented: New menu item added "Tools->Toggle font size" - toggles font size between 8, 9 and 10 for all elements 
- Implemented: Quick starter - new menu item added "Edit->Set font color for selected items"
- Implemented: Quick starter - it is possible to use quick filter for name (test), path (|test) or name and path (:test)
- Implemented: Status bar - placeholder for size in GB, TB added
- Implemented: Multirename - moving files in subfolder is possible now https://freecommander.com/forum/viewtopic.php?p=41789#p41789

- Changed: Rename dialog - original name field is enabled now


================================================================================
Important changes and bug fixes in the release 894
================================================================================   

- Bug fix: Exception on split file https://freecommander.com/forum/viewtopic.php?t=13563
- Bug fix: Delete key in viewer search field deletes file https://freecommander.com/forum/viewtopic.php?p=41613#p41613
- Bug fix: Customize toolbars dialog - command hints - minor issue https://freecommander.com/forum/viewtopic.php?t=13570
- Bug fix: Almost all keyboard shortcuts lost temporary https://freecommander.com/forum/viewtopic.php?p=41614#p41614


================================================================================
Important changes and bug fixes in the release 893
================================================================================   

- Implemented: Customize toolbars dialog - command hints are shown for choosed commands too
- Implemented: Backup all settings - the user can optional add part of the subfolder name
- Implemented: Quick filter added in dialog for column selection (Choose details)
- Implemented: New option in "Column profile" dialog added - "Size*" columns - calculate size from all subfolders (default value is true except plain view) 
- Implemented: New option in the freecommander.ini for refresh controlling in the plain view mode - DirMonPlainAllFolders=0; default value is 0: only changes in the base folder are monitored  
- Implemented: For command line parameter "-size" new values can be used: MIN, MAX, FULL
- Implemented: Mouse shortcuts in the file list - click position "detail column" splitted to "first detail column" and "other detail columns"; new function added "Free space context menu"
- Implemented: Copy with the FreeCommander method - multiple target folders are possible now; new option added "Copy to selected folders or links in the target panel"

- Bug fix: Refresh tree in the inactive panel does not work after creating new folder in the active panel
- Bug fix: Quick viewer - some files (e.g. flac, mp4, mov) can not be played if VLC Media Player is used; Viewer F3 works good
- Bug fix: New Folder dialog - the size is wrong on start
- Bug fix: Start with last used folders is broken https://freecommander.com/forum/viewtopic.php?t=13543

- Changed: Default delete operation in viewer changed from permanent delete to delete to recycle bin; both delete types are available for toolbar and shortcuts 


================================================================================
Important changes and bug fixes in the release 892
================================================================================   

- Bug fix: F1 does not work for the new install (if freecommander.shc.ini does not exists)
- Bug fix: Pressing Ctrl+Tab, if one item is in edit mode, perform select all items (file list is in detailed view mode) https://freecommander.com/forum/viewtopic.php?t=13490  
- Bug fix: Status bar in Search files/folders window not theming correctly https://freecommander.com/forum/viewtopic.php?p=41243#p41243
- Bug fix: Exif options - does not work without '.' on string end https://freecommander.com/forum/viewtopic.php?t=13453
- Bug fix: Tab caption maybe wrong https://freecommander.com/forum/viewtopic.php?t=13500
- Bug fix: Search dialog - quick filter maybe focused on dialog opening https://freecommander.com/forum/viewtopic.php?p=41347#p41347
- Bug fix: The options  "Quick search field auto close time" and  "Show in the right panel on the left" needs FC restart https://freecommander.com/forum/viewtopic.php?t=13507
- Bug fix: Keep filter on tab change - should keep empty quick filter too

- Changed: Attributes/Timestamp dialog: Created and modified timestamp checkboxes do not stay checked at the same time for "Set timestamp from EXIF"
- Changed: Viewer - shortcut for Settings changed to F12
- Changed: Viewer - shortcut for "View - Full Screen" changed to F11
- Changed: Viewer - shortcut for "Save as..." changed to Shift+Ctrl+S, shortcut Ctrl+S assigned to "Save"  

- Implemented: New action added - Copy modified timestamp;Copies modified timestamp of the focused item to clipboard for using in Attributes/Timestamp dialog
- Implemented: Favoriten tree - New item added in the context menu of the free space: Sort all items
- Implemented: Drag&drop item to file container favorite tools item is possible now 
- Implemented: History in the New Folder Dialog
- Implemented: Number of the favorite tools for shortcuts registration increased to 40
- Implemented: New menu item added - Tools-> Start FC as new instance with NewIni parameter
- Implemented: Confirmation dialog in viewer - for saving changes


================================================================================
Important changes and bug fixes in the release 891
================================================================================
- Bug fix: Exception on program start if quick filter option for visibility is set to false 
- Bug fix: Create new folders dialog (F7) use not the same font as other dialogs
   

================================================================================
Important changes and bug fixes in the release 890
================================================================================   

- Bug fix: Exception on toggling "Use f1 for showing help"  https://freecommander.com/forum/viewtopic.php?p=41018#p41018
- Bug fix: Tab properties dialog - if 'Use as base folder for the tree' is activated, path displayed in 'Locked path' field disappears https://freecommander.com/forum/viewtopic.php?t=13422
- Changed: Viewer (F3), if the option "Link to file list" is active, the focus, if possible, stay in the file list 
- Implemented: Multi Rename dialog, new option added "Auto reload after successful rename" 
- Implemented: Extended ability to create new folders (F7)
- Implemented: Viewer settings - extended ability to define the showed exif tags - now per file extension possible 
- Implemented: Quick filter settings - option for reverse sorting of the history items


================================================================================
Important changes and bug fixes in the release 889
================================================================================  
- Bug fix: Exception when closing Synchronize window, introduced in 888 

================================================================================
Important changes and bug fixes in the release 888
================================================================================  
- Bug fix: The list view maybe broken after opening/closing the tree if the option "Right align extension for details and list view" is active
- Bug fix: OneDrive symbols are visible only if the option "Settings->Select items: Use Windows colors" is not active  
- Buf fix: Not all mouse shortcuts are saved
- Bug fix: Status bar is not updated if select is made with the new mouse shortcut          
- Changed: Status bar in "Define action toolbars" dialog - spacing between quick filter and hint label incrased
- Changed: Favorite tool definition - if an LNK file is selected, then the path of the file and not the target path is used
- Changed: Quick filter shortcut is ignored in dialog windows if the shortcut definition does not include a Ctrl or Alt key
- Implemented: View of GodMode folder  https://freecommander.com/forum/viewtopic.php?p=40348#p40348
- Implemented: Number of layouts in toolbar extended up to 20
- Implemented: Synchronize - new option for using of the recycle bin for delete operations
- Implemented: New option in the "Define shortcuts" dialog - Use F1 for showing help



================================================================================
Important changes and bug fixes in the release 887
================================================================================  
- Bug fix: Exception on paste with Ctrl+V if only one panel is visible (introduced in 886)


================================================================================
Important changes and bug fixes in the release 886
================================================================================   

- Bug fix: Delete from the tree - no refresh if delete operation is performed by Windows
- Bug fix: Tab properties dialog - the size of the dialog is wrong if saved size is used on monitor with different resolution
- Bug fix: QuickStarter - reorganize function does not remove duplicates
- Bug fix: The order of the dropped items is wrong if the source of the operation is in the file cart
- Bug fix: Viewer - Hotkey for "Rotate anti clockwise" does not work for pdf files            
- Bug fix: The click with the middle mouse button on folder in the file list is broken (when no mouse shortcut is defined)
- Bug fix: Auto refresh on mapped webdav drive may not work
- Implemented: Tab properties - locked path can be defined in dialog (using of the environment variables is possible)
- Implemented: New option for rename operation: "Replace illegal characters with defined character" (Settings - File/folder operations )
- Implemented: Select per dragging can start in column if darg&drop only for name is allowed
- Implemented: Viewer settings - extension lists are sorted now
- Implemented: Mouse shortcuts added for columns
- Implemented: Favorite tree - if a path does not exist in the favorite, an error icon will be displayed in the tree for that item
- Changed: Drag&drop from the plain list changed          

================================================================================
Important changes and bug fixes in the release 885
================================================================================
Bug fix: Text search bar in quick viewer has false icons on the buttons 
Bug fix: The opion "Show/hide files tooltip" does not work reliably  https://freecommander.com/forum/viewtopic.php?p=40297#p40297
Bug fix: Duplicate favorite tool - same shortcut will be used in the duplicated item
Bug fix: Favoriten button in the toolbar does not work if the option "Use FreeCommander drawn Favorites menu" is not active
Bug fix: Synchronize folders dialog - display problem if the option "Auto compare on profile change or dialog open" is active  https://freecommander.com/forum/viewtopic.php?t=13280
Bug fix: Edit address bar (Alt+G) works not properly after switching dual/one panel (F10)
Implemented: New option in "Desktop snapshot" dialog - "Delay before starting the dnapshot (seconds)"
Implemented: Addres bar editing - color and font is taken from the address bar
Implemented: Addres bar editing - ~\ on the beginning of the edited address will be replaced with %userprofile%\ 
Implemented: Mouse shortcuts for right und middle buttons can be defined under Tools->Settings->File-/folder list: Mouse Shortcuts
Implemented: New action added "Select favorites set"
Changed: Favorite tool as a folder item - if defined path exists as tab on the active site, the tab will be activated. Otherwise the defined path will be opened in a new tab. 
           If you want to open pair of folders - use field "Parameter" for defining the second folder.

================================================================================
Important changes and bug fixes in the release 884
================================================================================
Bug fix: Possible exception if using the optiom "Use FreeCommander drawn Favorites menu"
Implemented: Option to define in the freecommander.ini ShowGridLines; possible values 0=none, 1=FC drawn, 2=Windows drawn
Implemented: Option to define in the freecommander.ini CreateTabOnFreeSpaceDblClick; default value 1, to disable tab creation use value 0 
Implemented: Option to define in the freecommander.ini FileListColoredColumnHeader; default value 1, to disable use of colors use value 0


================================================================================
Important changes and bug fixes in the release 883
================================================================================
Bug fix: Possible exception when deactivating the option "Use Windows drawn menus"
Bug fix: Possible exception on "Apply profile" in multi rename dialog
Implemented: Folder synchonize dialog - new option added "Use bold font in the file list" 
Implemented: File list grid lines are drawn with color of the menu line
Implemented: New option added Settings->View: Use FreeCommander drawn Favorites menu
Implemented: New option added Settings->File/folder list: Sorting: "Column sort symbol"  

================================================================================
Important changes and bug fixes in the release 880
================================================================================  
Bug fix: Multi rename - "Activate profiles combo box first" is broken  https://freecommander.com/forum/viewtopic.php?p=39876#p39876
Bug fix: After resizing the main window, some elements may be drawn not properly (red area may appear) https://freecommander.com/forum/viewtopic.php?t=13170

================================================================================
Important changes and bug fixes in the release 879
================================================================================        
Bug fix: Focused item rectangle is not properly drawed if "Show gridlines" option is active
Bug fix: Possible stack overflow on program start if the tree pane is visible and "Start minimized" option is active  
Bug fix: Cursor maybe not visible in editing mode (file list) if colored column headers option is active   
Implemented: Desktop snapshot - variables %ActivDir%, %InactivDir% are possible now as destination folder 

================================================================================
Important changes and bug fixes in the release 878
================================================================================
Bug fix: Background color maybe wrong (text is not visible) if renaming item in the file list.

================================================================================
Important changes and bug fixes in the release 877
================================================================================
Bug fix: With the "White_Default" color scheme the hex view has wrong background color
Bug fix: Searching for content fail for files with path longer as 260 characters   https://freecommander.com/forum/viewtopic.php?p=39735#p39735
Bug fix: Quick filter does not work for lnk files in Recycle Bin
Bug fix: Filter Alt+Y does not work for lnk files in Recycle Bin 
Bug fix: System tray icon is not always visible on Windows 11 https://freecommander.com/forum/viewtopic.php?p=39758#p39758 
Bug fix: Context menu item for Mp3tag is broken
Implemented: New possibility to change of the folder timestamp in the "Attributes/Timestamp" dialog: Set folder timestamp from most recent item
Implemented: Column headers are now colored if any color scheme is active; For disabling colors define FileListColoredColumnHeader=0 in the freecommander.ini file



================================================================================
Important changes and bug fixes in the release 876
================================================================================
Bug fix: Program crash if the "OneDrive Status" column is visible and operation copy, move, delete is performed
Bug fix: Wrong folder may be selected in the tree on the program start https://freecommander.com/forum/viewtopic.php?p=39302#p39302
Bug fix: Search dialog doesn't find content of folder with semicolon in its name https://freecommander.com/forum/viewtopic.php?t=10755
Bug fix: Tree panel per Site -> the tree width may be not properly set after F10 or program start
Bug fix: Synchronization - exclude folders filter is broken if the option "Include Empty folders" is active
Bug fix: Panel focus issue on copy/paste or delete file (regression)  https://freecommander.com/forum/viewtopic.php?p=39559#p39559


================================================================================
Important changes and bug fixes in the release 875
================================================================================   

Bug fix: Selecting thumbnails with Shift key doesn't work properly https://freecommander.com/forum/viewtopic.php?p=39505#p39505
Bug fix: Rename per slow double click is broken if the option "Hot track only" is active (Windows selection mode only)  
Bug fix: Sorting using toolbar button does not respect setting for sorting direction   
Changed: Favorite folder tree - now category item will be opened with delay if dragging some item over
Changed: Quick starter - the case of all items in the repository is now used "as is".
Implemented: Quick starter - rename function added 
Implemented: Viewer - new setting option "Zoom filter" 
Implemented: New settings option added "One viewer for both panels - left-aligned"
Implemented: New FreeCommander column type added "OneDrive status" - OneDrive icons are displayed 
Implemented: Attributes/Timestamps dialog - it is possible now to set random timestamps
Implemented: Compare folders - new option added "Ignore diacritical marks"

================================================================================
Important changes and bug fixes in the release 874
================================================================================                                                                                
Changed: Improved handling of the shell libraries    
Implemented: New view type added "Thumbnail labels" Alt+B
Implemented: New condition for auto selecting of the column profile: <thumbnail_labels> 

================================================================================
Important changes and bug fixes in the release 873
================================================================================   
Bug fix: Changing the option "Show hidden" - change only inactive site
Bug fix: AdressBar, Splitter toolbar - divider width definition is ignored https://freecommander.com/forum/viewtopic.php?p=39045#p39045
Bug fix: Semicolon sign cannot be used for icons on Address Bar, Splitter, action toolbar https://freecommander.com/forum/viewtopic.php?p=39048#p39039
Bug fix: Starting the drag operation may fail in detail view mode if the option "Show extension in Name column" is not active
Bug fix: Text in Hot Area in the Address Bar moves down when hovered upon https://freecommander.com/forum/viewtopic.php?t=12878
Bug fix: Viewer - problems with the "Document title" setting options https://freecommander.com/forum/viewtopic.php?t=12884
Bug fix: Click with middle mouse button on folder created on desktop causes exception  https://freecommander.com/forum/viewtopic.php?t=12897
Bug fix: Exclamation point in a filepath causes incorrect link to be displayed in file preview  https://freecommander.com/forum/viewtopic.php?p=39157#p39157
Bug fix: PowerRename item from context menu opens twice the tool https://freecommander.com/forum/viewtopic.php?p=39142#p39142
Bug fix: Save settings problem on Windows 7 https://freecommander.com/forum/viewtopic.php?t=12924
Changed: Favorite tools - items without defined "Program or folder" are visible now in the submenu of the category https://freecommander.com/forum/viewtopic.php?p=39127#p39127
Changed: TABs - properties dialog is now sizeable
Changed: Option "Handle closing as minimization" now only for click on X symbol
Implemented: Search dialog - it is possible to define ignore list for folder names: Options-> Ignore list for folders
Implemented: Search dialog - it is possible to ignore folders with the attribute: System, Hiden or System and Hidden
Implemented: New view type added "Thumbnail list" Alt+L
Implemented: New condition for auto selecting of the column profile: <thumbnail_list> 


================================================================================
Important changes and bug fixes in the release 872
================================================================================   
Bug fix: Show column headers option not saved on program close
Bug fix: Position of the main splitter not properly set after orientation changing (Ctrl+H)
Bug fix: Auto size columns function is broken if using the option "By item name length"


================================================================================
Important changes and bug fixes in the release 871
================================================================================        
Bug fix: Exception when copying the file to the archive if the option "Move to archive" is activated.
Bug fix: Favorites may not working when using multiple favorite sets                    
Implemented: Copy dialog (FreeCommander method) - new option on settings tab for copying of the symbolic links
Implemented: Make folder list dialog - new option on settings tab "Load method for symbolic link of folder"
Implemented: New action added: "Quick search - searched fraction at start; Toggles the option: Searched fraction must exists at the beginning of the text" 
Implemented: New action added "Show/hide column headers" Shift+Ctrl+H
Implemented: New view type added "Thumbnail details" Alt+I
Implemented: New condition for auto selecting of the column profile: <thumbnail_detail> 

================================================================================
Important changes and bug fixes in the release 869
================================================================================
Bug fix: File popup menu in address bar maybe displayed on wrong position (multi monitor system)
Bug fix: Tree pane - selected node may be not visible on program start
Bug fix: Viewer - exception if switching VLC player in full screen mode when new color scheme (FreeCommander_Dark, FreeCommander_Dark_Blue, FreeCommander_Light, FreeCommander_Solarized) is active (64 bit)
Implemented: Favorite tree - with Ctrl+Click on icon or label full collapse/expand is made 
Implemented: New action defined "Create symbolic link..."
Implemented: New action defined "Copy symbolic link..."
Implemented: FreeCommander copy dialog - new option on "Settings" tab added "When copying symbolic link of folder"

================================================================================
Important changes and bug fixes in the release 868
================================================================================
Bug fix: After minimize to systray and restore with click on the program icon exception is possible
Bug fix: The width of the tree maybe wrong after FC restart if "One tree per panel" option is used - it was not properly fixed in 866, 867 
Bug fix: Exception in viewer if VLC player is used https://freecommander.com/forum/viewtopic.php?p=38637#p38637 

================================================================================
Important changes and bug fixes in the release 867
================================================================================

Bug fix: The width of the tree maybe wrong after FC restart if "One tree per panel" option is used - it was not properly fixed in 866  
Bug fix: Edit favorite tools - setting of the icon file does not set icon number to 0 as in the past  https://freecommander.com/forum/viewtopic.php?p=38474#p38474
Bug fix: "Redirect Win+E to freeCommander" - Started program is opened in the background

Implemented: Synchronize folders - new "Include" Option added: Selected folders only. 
Implemented: New function added "View -> Reset view (Alt+R)". For active panel and active tab the following options will be reset: quick filter, filter, plain view, all "only selected".     

Changed: The function "View only selected in both panels" works if no other "only selected" view is active in either panel. Otherwise the existing "only selected" view will be switched off.
Changed: The functions "View only selected files", "View only selected items", "View only selected in both panels" were changed internally. If used as a toolbar button, they must be removed from the toolbar and added again.
Changed: Compare folders (Alt+V) - it is possible now to select different or same items (till now only different)


================================================================================
Important changes and bug fixes in the release 866
================================================================================

Bug fix: Closing main FC window if multi rename form is open may cause exception   
Bug fix: Multi rename - "Activate profiles combo box first" is broken 
Bug fix: "Remove color scheme..." does not remove it from menu 
Bug fix: Layouts - editing is broken if quick filter is active https://freecommander.com/forum/viewtopic.php?t=12624
Bug fix: Exception is possible if new scheme (FreeCommander_*)  is used and view style is set to not custom
Bug fix: The width of the tree maybe wrong after FC restart if "One tree per panel" option is used   
Bug fix: Folder synchronize - rename profile function is broken

Implemented: File search window - double click in the profile list activate the profile
Implemented: Favorite tools - new variable added %ActivItemOnlyExt"
Implemented: Multi rename - md5 and crc32 checksums can be used   
Implemented: "Settings - File/folder operations - Rename/Create" - new option added "Delay in miliseconds" for rename on slow double click
Implemented: Address bar - popup menu für subfolders now with scroll bar  

Changed: Default value for the option Settings-General: "Activate Jump List" changed to false


================================================================================
Important changes and bug fixes in the release 865
================================================================================

Bug fix: History drop down buttons broken on program start
Bug fix: Folder size value directly after program start maybe wrong (e.g. folder c:\windows)
Bug fix: Multi rename - option "Activate profiles combo box first" broken
Bug fix: Unpacking bigger (> 4GB) files from zip archive is not possible 


================================================================================
Important changes and bug fixes in the release 864
================================================================================

Bug fix: Starting with parameters (e.g. /N /L=D:) does not update the tree and tab caption
Bug fix: Exception is possible when switching from dual panel to one panel and quick viewer is open
Bug fix: Layouts edit - using ENTER while renaming the item, closes the entire dialog

Implemented: If "Quick search" is active it is possible now to set the "Quick Filter" from the content of the quick search field - use Ctrl+Y when the quick search field is visible. 
Implemented: If "Quick search" is active it is possible now to select all items matched with the content of the quick search field - use Ctrl+A when the quick search field is visible.
Implemented: QuickFilter setting added: Clear all on program closing
Implemented: PDF viewer (64 bit) - bookmarks display added
Implemented: PDF viewer (64 bit) - document printing added
Implemented: Automatic views - "Show size of folders" property added
Implemented: Search for duplicates - more selection functions added
Implemented: New option added Settings->General: Activate Jump List

================================================================================
Important changes and bug fixes in the release 863
================================================================================

Bug fix: Settings - definition of the new items for column profiles, automatic views and status bar is broken 
Bug fix: Toolbar in quick viewer can not be made visible
Implemented: Cover for EPUB files is displayed in the Viewer and Quick Viewer


================================================================================
Important changes and bug fixes in the release 860
================================================================================

Bug fix: Exception on swap panels if option "Quick filter bar always visible" is not active 
Bug fix: Navigation through the history is broken if the file path contains the '=' character
Bug fix: Internal PDF quick viewer - using Backspace or Delete key in the search field perform actions in main window 
Bug fix: Internal PDF quick viewer - previous/next buttons issue https://freecommander.com/forum/viewtopic.php?f=7&t=12352
Bug fix: Selected item color issue  https://freecommander.com/forum/viewtopic.php?f=7&t=12349
Bug fix: Restored layout does not set the main window in the proper position on the screen
Bug fix: The TAB context menu that is called up with a key combination does not contain all elements

Implemented: New action added - Edit -> Select same files in both panels
Implemented: New action added - View -> Only selected in both panels
Implemented: New color scheme "FreeCommander_Dark_Blue", all dialogs have the colors too (64 bit only)
Implemented: New color scheme "FreeCommander_Solarized", all dialogs have the colors too (64 bit only)
Changed: Special file list background colors are ignored for inactive panel https://freecommander.com/forum/viewtopic.php?f=20&t=12396
Changed: Viewer - VLC Player improved


================================================================================
Important changes and bug fixes in the release 859
================================================================================
Bug fix: Possible exception while deleting files


================================================================================
Important changes and bug fixes in the release 858
================================================================================

Bug fix: When double clicking the bottom row in detailed view, the item below may be opened  https://freecommander.com/forum/viewtopic.php?f=7&t=12320
Bug fix: Pressing ESC while multi rename dialog is opened can throw an exception
Bug fix: Swap panel with the same path issues https://freecommander.com/forum/viewtopic.php?f=7&t=12332   
Implemented: Jump list on taskbar icon
Implemented: New option added Settings->General: Clear Jump List on close
Implemented: Multirename - new option added: "Resolve duplicates with auto counter"
Implemented: Multiirename - new action added: "Rename using text editor" 
Implemented: Synchronize -  unequal files can now be selected for copying in the Synchronize dialog
Implemented: New color scheme "FreeCommander_Dark", all dialogs have the colors too (64 bit only)       


================================================================================
Important changes and bug fixes in the release 855
================================================================================

Bug fix: When opening the ZIP files, an exception can occur if additional columns have been defined in the display

================================================================================
Important changes and bug fixes in the release 854
================================================================================

- Bug fix: Saving of the overwrite options in copy dialog is broken
- Bug fix: Exception in Synchronize dialog - broken options: "Auto compare on filter change", "Auto compare on profile change or dialog open"
- Bug fix: Some fileds in settings dialog are black on Windows XP
- Implemented: SFTP - new login type: Interactiv
- Implemented: New color scheme "FreeCommander_Light", all dialogs have the colors too (64 bit only)       


================================================================================
Important changes and bug fixes in the release 853
================================================================================

- Bug fix: Changing a file from jpg to pdf in the viewer leads to two visible toolbars
- Bug fix: Exception on renaming pdf file in viewer
- Bug fix: Tree setting "Make selected node automatically visible" maybe broken
- Bug fix: Path-link in address bar may open wrong folder     https://freecommander.com/forum/viewtopic.php?f=7&t=12187
- Implemented: New command line parameter added "-ColorScheme="
- Implemented: Settings dialog is no more modal  
- Implemented: File container file (*.fcc) can be opened from favorite tools toolbar and from favorites tree    https://freecommander.com/forum/viewtopic.php?f=18&p=37093#p37093

================================================================================
Important changes and bug fixes in the release 852
================================================================================

- Bug fix: Possible exception on deleting file (FC dialog) if admin rights were requested - 851 only
- Bug fix: Possible exception on copy/move files (FC dialog with Shift+F5, Shift+F6) - 851 only  

================================================================================
Important changes and bug fixes in the release 851
================================================================================

- Bug fix: Internal viewer - F3 key issue with images (in 850 only) https://freecommander.com/forum/viewtopic.php?f=7&t=12061
- Bug fix: Internal viewer - flickering when switching images (in 850 only) https://freecommander.com/forum/viewtopic.php?f=7&t=12064   and https://freecommander.com/forum/viewtopic.php?f=7&t=12063
- Bug fix: File list loses keyboard focus if Quick View shows a pdf file https://freecommander.com/forum/viewtopic.php?f=7&t=12153
- Bug fix: Automatic views doesn't work with favorites https://freecommander.com/forum/viewtopic.php?f=19&p=36931#p36931
- Implemented: "Show all pages" new option in the context menu of the internal PDF viewer 
- Implemented: Thumbnails view for ai (Adobe Illustrator) files
- Implemented: Favorite tools - up to 3 prompt parameters are possible https://freecommander.com/forum/viewtopic.php?f=20&p=36926#p36926
 

================================================================================
Important changes and bug fixes in the release 850
================================================================================

- Bug fix: "Linked browsing" does not work in detail view mode if extension is not showed
- Bug fix: Exception in internal viewer if quickly F3 and ESC pressed
- Changed: Viewer - quality for JPEG file is now preserved when saving a file
- Changed: Viewer - when saving image as JPEG the extension jpg is now used
- Implemented: Internal viewer for PDF files (64 bit only). No more extra software needed for showing pdf files.
- Implemented: Searching for content in PDF files is now without converter possible (64 bit only) 

================================================================================
Important changes and bug fixes in the release 849
================================================================================  
- Bug fix: Icons in favorite tools menu shown incorrectly https://freecommander.com/forum/viewtopic.php?f=9&t=11956
- Bug fix: Wrong numbering of the favorite tools https://freecommander.com/forum/viewtopic.php?f=7&t=11955
- Bug fix: Tree visibility is broken if first tab is created https://freecommander.com/forum/viewtopic.php?f=7&t=11959
- Bug fix: Wrong icons in the favorites subfolders https://freecommander.com/forum/viewtopic.php?f=19&t=11984
- Implemented: Using of the old icons is possible after adding in the [Icons] section of the freecommander.ini: UseOutdatedBmps=1 
- Implemented: Renaming file in viewer is possible now
- Implemented: Layouts dialog - quick filter field added


================================================================================
Important changes and bug fixes in the release 848
================================================================================
- Bug fix: The option "Show confirmation dialog on exit" is ignored if the program is closed via the context menu from the symbol in system tray
- Bug fix: Exception on reading file tags via exiftool 
- Bug fix: The size of the the custom icons in address bar is wrong

================================================================================
Important changes and bug fixes in the release 847
================================================================================
- Bug fix: Multi rename dialog - focus problem with the profile droplist https://freecommander.com/forum/viewtopic.php?f=19&t=11858
- Bug fix: Viewer (ExifTool) - Metadata Tag title seems utf-8 but shows as locale https://freecommander.com/forum/viewtopic.php?p=36281#p36281 
- Bug fix: Option "Tab Sequence: Reverse" is broken
- Changed: The old, not flat icons are no more available
- Implemented: New icons set is available "Flat Pro"
- Implemented: Tools->Settings->View - new tab "Icons sets" is available. Here can be selected the used icon set. 

================================================================================
Important changes and bug fixes in the release 846
================================================================================
- Bug fix: Multi rename dialog - multiple fields are highlighted on start  https://freecommander.com/forum/viewtopic.php?f=19&p=35984#p35984    
- Bug fix: Start folder from command line is not set for folders defined as e.g. -L=::{20D04FE0-3AEA-1069-A2D8-08002B30309D} 
- Bug fix: File container - selection is lost on tab change 
- Bug fix: Progress bar for SFTP download and upload is broken 
- Implemented: Multi rename dialog - Ctrl+P hotkey for opening of the profiles selection list   
- Implemented: Multi rename dialog - the auto preview timer slows down when the progress dialog box appears
- Changed: File and folder timestamp: daylight saving time is taken into account (as in Windows Explorer)   
- Changed: New icons in dialogs 


================================================================================
Important changes and bug fixes in the release 845
================================================================================
- Bug fix: Thumbnails for pdf files (if Adobe Reader as default pdf program is installed) maybe not showed in the 64 bit version
- Bug fix: Some thumbnails have wrong background color   https://freecommander.com/forum/viewtopic.php?f=7&t=11609     https://freecommander.com/forum/viewtopic.php?f=7&t=11608
- Bug fix: Customize favorite toolbars > New item > File > Seek icon file: the file select dialog is hidden behind other windows  http://freecommander.com/forum/viewtopic.php?p=34914
- Bug fix: Selection of the last item with Shift+Right in thumbnail view maybe wrong https://freecommander.com/forum/viewtopic.php?f=7&t=11433
- Bug fix: Option "Keep filter on tab changed" is not saved in the freecommander.ini (you can change the option manually QuickFilterKeepOnTabChange)
- Bug fix: Draw caption without clipping wrong after refresh https://freecommander.com/forum/viewtopic.php?f=7&p=35691#p35691
- Bug fix: Total progress bar in copy dialog broken 
- Changed: Overlay icons in the tree are loaded now in background
- Changed: Default value for the option "Keep filter on tab changed" changed to TRUE
- Changed: Quick filter option "Deactivate filter on folder change" changed to "Keep filter on folder change"; default value FALSE
   
   

================================================================================
Important changes and bug fixes in the release 844
================================================================================
- Bug fix: Possible exception on program start if favorites tree is active

================================================================================
Important changes and bug fixes in the release 843
================================================================================
- Bug fix: Exception when opening favorites tree if "Use big icons" option is active.

================================================================================
Important changes and bug fixes in the release 842
================================================================================
- Bug fix: Command line -size= parameter does not work if using without -NewIni= parameter  https://freecommander.com/forum/viewtopic.php?f=7&t=11434
- Bug fix: "Folder->Open focused/selected" does not work if only file is selected https://freecommander.com/forum/viewtopic.php?f=19&p=35168#p35168
- Bug fix: "Left -> Right" / "Right -> Left" hidden buttons right click issue  https://freecommander.com/forum/viewtopic.php?f=7&p=35169#p35169
- Bug fix: Packing multiple files with "Create one archive per file" wrong path issue https://freecommander.com/forum/viewtopic.php?f=7&t=11501
- Bug fix: Invalid character issue when creating new folder https://freecommander.com/forum/viewtopic.php?f=7&t=11442
- Bug fix: Selection problem if options for "hot track" and "open with single click" are active  https://freecommander.com/forum/viewtopic.php?f=19&p=35212#p35212
- Bug fix: Activating of the quick filter with Ctrl+Enter may not work  https://freecommander.com/forum/viewtopic.php?f=19&p=35263#p35263
- Bug fix: Thumbs for PSD files broken in the 64 bit version
- Bug fix: Viewer settings opened from Tools-Settings dialog are not saved when quick viewer is open https://freecommander.com/forum/viewtopic.php?f=19&p=35451#p35451   
- Bug fix: Quick search - up arrow does not work with special characters  https://freecommander.com/forum/viewtopic.php?f=7&p=35447#p35447
- Bug fix: Lines overlap when scrolling quickly with the mouse wheel
- Bug fix: Defined color for inactive file container tab is not used   
- Implemented: New option "Copy folder structure only" added in the copy dialog; only for "Use FreeCommander method"
- Implemented: Viewer settings - possibility to using of exiftool.exe for showing file metadata   https://exiftool.org/
- Implemented: Multirename - metadata from exiftool can be used
- Implemented: New option for quick filter - "Show in the right panel on the left" 
- Implemented: For "Queue status bar visible" option "Only if any operation exists" is defined delay time for closing:  OperationQueuePanelClosingTimeSec=8
 

================================================================================
Important changes and bug fixes in the release 841
================================================================================
- Bug fix: Verify checksums does not work if source file is on the Desktop
- Bug fix: Search form: "copy" from context menu in the result list and then paste in some folder may not work
- Bug fix: If the Name column is not the first, columns to the left of the Name column are empty (only if "Use Windows colors" is false)
- Bug fix: Occupied space progress bar maybe wrong after some file operations  https://freecommander.com/forum/viewtopic.php?f=9&t=11429
- Bug fix: Right click on the free area in the file list - submenu "New" has sometimes wrong icons
- Bug fix: Favorite tool - %ActivSelName% is not resolved if "Separate for each selected item" is used
- Bug fix: Exception on switch to FTP if the pane width is small
- Bug fix: QuickStarter - ":" allowed now for quick filter  https://freecommander.com/forum/viewtopic.php?f=7&t=11404
- Bug fix: Delete from container (FC) - request Admin rights
- Bug fix: Item focus lost after error dialog  https://freecommander.com/forum/viewtopic.php?f=9&t=11426
- Bug fix: Status bar tooltip for size don't show units "kB" and "MB" https://freecommander.com/forum/viewtopic.php?f=9&t=11424
- Bug fix: Set filter (Alt+Y) dialog - "Not older than" and "Older then" options can't be clicked https://freecommander.com/forum/viewtopic.php?f=9&t=11430
- Bug fix: Quick starter settings - editing the name of a 'color by' item erroneously creates a new item https://freecommander.com/forum/viewtopic.php?f=9&t=11406
- Bug fix: Multi rename - Stay on top issue with Viewer/Search https://freecommander.com/forum/viewtopic.php?f=9&t=11437
- Bug fix: Add plugin dialog issue, if using Stay on top option in viewer https://freecommander.com/forum/viewtopic.php?f=9&t=11436
- Bug fix: CopyFullPath_AddLastDelimiter=1 ini option issue https://freecommander.com/forum/viewtopic.php?f=9&t=11440
- Bug fix: New item in the dark favorite toolbar has unreadable font color https://freecommander.com/forum/viewtopic.php?f=9&t=11444
- Bug fix: Compute checksums shows "0 Error(s)" even if error is found  https://freecommander.com/forum/viewtopic.php?f=9&t=11427
- Bug fix: Search window focus issue, if stay on top option is used https://freecommander.com/forum/viewtopic.php?f=9&t=11432
- Bug fix: Delete confirmation dialog from file container - Esc doesn't work https://freecommander.com/forum/viewtopic.php?f=9&t=11438
- Bug fix: Rename of the favorite tools category may generate exception https://freecommander.com/forum/viewtopic.php?f=9&t=11464
- Bug fix: Viewer settings color/text issue https://freecommander.com/forum/viewtopic.php?f=9&t=11466 
- Changed: Creating of the default names for the favorite tools categories https://freecommander.com/forum/viewtopic.php?f=9&t=11463 
- Implemented: Search form - column widths of the result list are saved now
- Implemented: New checksum type added CRC32 


================================================================================
Important changes and bug fixes in the release 840
================================================================================
- Bug fix: Exception may occurs on switching between one and two panels

================================================================================
Important changes and bug fixes in the release 835
================================================================================
- Bug fix: Program freezes on startup if the drive last used is no longer connected and  plain view mode was used on program close. https://freecommander.com/forum/viewtopic.php?f=19&p=34572#p34572
- Bug fix: Focus is lost on refresh if option "Switch view mode automatically ..." is active https://freecommander.com/forum/viewtopic.php?f=7&t=11288
- Bug fix: Tree maybe not shown if switching from single-panel to dual-panel mode https://freecommander.com/forum/viewtopic.php?f=7&p=34584#p34584
- Bug fix: Sorting is wrong if auto selectable view is active and all options are set to "No change" https://freecommander.com/forum/viewtopic.php?f=7&p=34598#p34598 

================================================================================
Important changes and bug fixes in the release 834
================================================================================
- Bug fix: Exception on maximize window in one panel mode (introduced in 833)

================================================================================
Important changes and bug fixes in the release 833
================================================================================
- Bug fix: Dialog display issue after FC restart with 'Defined font' for dialogs https://freecommander.com/forum/viewtopic.php?f=7&t=11152
- Bug fix: File list display issues after renaming https://freecommander.com/forum/viewtopic.php?f=7&t=11150
- Bug fix: Quick filter delete/backspace bug  https://freecommander.com/forum/viewtopic.php?f=7&p=34195#p34195
- Bug fix: File container drag&drop and cut refresh issue  https://freecommander.com/forum/viewtopic.php?f=7&t=11185
- Bug fix: Automatic view may not work if the "View type" option is set to <No change>
- Bug fix: Some tabs are not created when the layout is restored https://freecommander.com/forum/viewtopic.php?f=19&t=11224&p=34408#p34408
- Bug fix: Quick search does not work properly if some other options are active https://freecommander.com/forum/viewtopic.php?p=34405#p34405 
- Implemented: New action added - Show layouts popup menu 
- Implemented: New action added - Change to last active tab (Ctrl+PgUp)
- Implemented: New timestamp formats added for the definition of the screenshot file name 
- Implemented: New option for quick filter - Keep filter on tab change
- Implemented: New placeholder for using in the status bar: [fc_columnProfile] - name of the used column profile 


================================================================================
Important changes and bug fixes in the release 832
================================================================================
- Bug fix: Focus is lost if going back from archive file (introduced in 831)
- Bug fix: Focus is lost after disabling quick filter (only when using plain view) https://freecommander.com/forum/viewtopic.php?f=7&t=11085
- Bug fix: Few stay on top issues  https://freecommander.com/forum/viewtopic.php?p=33954#p33954
- Bug fix: Exception in search dialog https://freecommander.com/forum/viewtopic.php?f=19&p=34028#p34028
- Bug fix: Bug in saving settings (FavoritesTreeColorSelectedNodeInactive) https://freecommander.com/forum/viewtopic.php?f=7&t=11044
- Bug fix: Selection maybe broken if hover time is used
- Bug fix: Position issue when switching modes in plain view https://freecommander.com/forum/viewtopic.php?f=7&t=11101
- Bug fix: Quick viewer and status bar is not updated when using "focus previous/next item" https://freecommander.com/forum/viewtopic.php?f=7&t=11080
- Bug fix: Language defined as command line parameter is not correctly set https://freecommander.com/forum/viewtopic.php?f=7&t=11136
- Bug fix: Multi rename problem https://freecommander.com/forum/viewtopic.php?f=7&t=10701
- Implemented: Thumbnail size 1024 added (for high resolution monitors) 
- Implemented: Volume buttons added for VLC player



================================================================================
Important changes and bug fixes in the release 831
================================================================================
- Bug fix: Position of active item is not updated when using quick viewer https://freecommander.com/forum/viewtopic.php?f=7&t=11028
- Bug fix: Column width in list view mode is wrong after switching from other view (introduced in 829) 
- Bug fix: If we press backspace in a subfolder, FC goes to parent folder, but sometimes fails to focus on the subfolder (when folders are sorted at the end of the list and extension ist not showed in the name column)
- Bug fix: Selection by hover time and Shift/Ctrl is broken
- Implemented: Tab context menu - new menu item added "Switch locked path to current" 

================================================================================
Important changes and bug fixes in the release 830
================================================================================
- Bug fix: Exception in Folder->Synchronize function (introduced in 829)
- Bug fix: Viewer - mouse wheel zoom function is inverted 
- Bug fix: New status bar item can not be created if program started with default settings parameter https://freecommander.com/forum/viewtopic.php?f=7&t=10993
- Bug fix: Minor Toolbars dialog filter vs icons issue https://freecommander.com/forum/viewtopic.php?f=7&t=10991
- Bug fix: Existent 1st keyboard shortcut is not removed if new one is assigned https://freecommander.com/forum/viewtopic.php?f=7&t=10989


================================================================================
Important changes and bug fixes in the release 829
================================================================================
- Bug fix: Viewer - "fit to window" sometimes is broken
- Bug fix: The position of the scroll bar may be wrong after switching from detailed view to thumbnail view. https://freecommander.com/forum/viewtopic.php?p=33408#p33408
- Bug fix: Temporary and not locked file container TAB not always removed on program closing
- Bug fix: Aborting the drag&drop operation with ESC can lead to an unwanted selection of files/folders (NC selection mode)
- Bug fix: Viewer form (F3) option "Stay on top" does not work correctly
- Implemented: New action - focus newest file/item in the list (by last access timestamp)
- Implemented: New action - focus next/previous item in the list
- Implemented: Attributes/Timestamp dialog - set file timestamp from EXIF
- Implemented: Settings->Tree - new color can be defined "Selection - Inactive"
- Implemented: Settings->Tree - new color can be defined "Background - Inactive"
- Implemented: Viewer form (F3) - set window to foreground if already open and use last saved size/position if multiple window allowed. 


================================================================================
Important changes and bug fixes in the release 828
================================================================================
Changing compiler version to Delphi 10.4 patch 2
I recommend using this version.
With the new compiler version, the unspecific errors in versions 825, 826, 827 have been fixed.


================================================================================
Important changes and bug fixes in the release 827
================================================================================
- Bug fix: Exception on main window activating if only one pane visible and refresh option "Refresh when FreeCommander is activated" is checked
- Bug fix: The window position saving does not work when you are not on the main screen (multi screen) https://freecommander.com/forum/viewtopic.php?f=7&t=10845
- Bug fix: Program start is faulty and program can not be closed - this behavior only appears when the program is started from a shortcut that has "Properties/Shortcut/Run: Maximized" https://freecommander.com/forum/viewtopic.php?f=7&t=10838 
- Bug fix: Overlay symbol in the file operation dialogs is not showed (status symbol for operation result)
- Bug fix: Manipulate files with emojis in their name is not possible https://freecommander.com/forum/viewtopic.php?p=33397#p33397

================================================================================
Important changes and bug fixes in the release 826
================================================================================
- Bug fix: Default action issue with multiple files https://freecommander.com/forum/viewtopic.php?f=7&t=10797
- Bug fix: Function "Same folder Ctrl+E" sometime does not switch the folder properly
- Bug fix: The context menu for Bitlocker "Unlock drive" may not work (introduced in 825)
- Changed: Viewer settings - "Ignore list" changed to "Ignore files - filter list"

================================================================================
Important changes and bug fixes in the release 825
================================================================================
- Bug fix: Window size and position lost when exit from fullscreen https://freecommander.com/forum/viewtopic.php?f=7&t=10777
- Bug fix: Tabs drag&drop - always active tab is dropped if the option "With click on the active tab - change to the last active" is active
- Bug fix: Color picker is to small on 4K monitors
- Bug fix: Column caption maybe wrong (introduced in 824)
- Implemented: Make folder/file list - timestamp format added on Settings tab

================================================================================
Important changes and bug fixes in the release 824
================================================================================
- Bug fix: Wrong data populating (right-shifted columns) after F10 (top/bottom split) https://freecommander.com/forum/viewtopic.php?f=7&t=10764
- Bug fix: Column width not remembered across close/re-open https://freecommander.com/forum/viewtopic.php?f=7&t=10763
- Bug fix: Recycle Bin panel switch issue https://freecommander.com/forum/viewtopic.php?f=7&t=10070


================================================================================
Important changes and bug fixes in the release 823
================================================================================
- Bug fix: The definition of the font size for dialogs (Tools->Settings->View) does not work for Settings dialog 
- Bug fix: "Layouts edit" dialog - after deleting of the last layout the OK button is not active (it is not possible to delete all layouts)
- Bug fix: Problems with the top/bottom orientation fixed (introduced in 820, 821)
- Bug fix: Mounted volume size is not properly shown in progress bar of the drive bar
- Bug fix: Search dialog doesn't find content of folder with semicolon in its name https://freecommander.com/forum/viewtopic.php?f=19&t=10755
- Implemented: Drive panel - width of the volume name button is definable in the setting 
- Implemented: Support for 4K monitors 


================================================================================
Important changes and bug fixes in the release 822
================================================================================
- Bug fix: Favortite tools broken if no parameter used in the favorite tool definition - introduced in the release 821


================================================================================
Important changes and bug fixes in the release 821
================================================================================
- Bug fix: Focus is lost if deleting a file in the thumb view mode  https://freecommander.com/forum/viewtopic.php?p=32735#p32735
- Bug fix: Next/previous tab shortcuts broken when using some context menu options https://freecommander.com/forum/viewtopic.php?p=32727#p32727
- Bug fix: Tab name maybe not updated https://freecommander.com/forum/viewtopic.php?f=7&t=10628
- Bug fix: Tooltip for button in the action toolbar maybe wrong if custom icon is used
- Bug fix: Renaming a file that is open in Quick View can break the display in Quick View. 
- Implemented: Quick Viewer - Copy selected text to the clipboard with the shortcut Ctrl+C.
- Implemented: SFTP (64 bit only) - public key login is possible now 

================================================================================
Important changes and bug fixes in the release 820
================================================================================
- Bug fix: A new tab is created when the favorite is opened using a hotkey (introduced in 819)
- Bug fix: Status info for '..' item was never used
- Bug fix: Keyboard shortcuts maybe lost when using "Desktop Snapshot" https://freecommander.com/forum/viewtopic.php?f=7&t=10595
- Bug fix: Sorting Windows columns of date type does not work properly for many timestamp formats (e.g. in recycle bin)
- Bug fix: Opening program links from the FreeCommander Desktop is broken https://freecommander.com/forum/viewtopic.php?f=6&p=32684#p32684
- Implemented: When started "As Admin": Warning symbol is added to the program icon - new option in Settings->View
- Implemented: New variable added %ActivSelOrDir% - same as %ActivSel% but return current path if nothing is selected in the file list (for example when selecting ".." in file list)
- Implemented: New action added - Close all tabs in both panels; Closes all not locked folder tabs in both panels
- Implemented: New action added - Close all tabs with confirmation; Closes all folder tabs with confirmation dialog
- Implemented: New action added - Select the first file / folder; Select first file (if currently focused item is a folder) or folder (if currently focused item is a file) in the list

================================================================================
Important changes and bug fixes in the release 819
================================================================================

- Bug fix: Keyboard shortcuts do not work in Quick View pane
- Bug fix: Unassigning secondary keyboard does not get saved https://freecommander.com/forum/viewtopic.php?f=7&t=10510
- Bug fix: Secondary keyboard shortcuts not always being saved https://freecommander.com/forum/viewtopic.php?f=7&t=10513
- Bug fix: Exception possible if copy/move files from library 
- Implemented: When started "As Admin": Warning symbol is added to the program icon and the word "(Admin)" appears in the title bar.
- Implemented: Thumbnails for SVG files
- Implemented: SFTP - Symbolic links are properly handled now
- Implemented: "Attributes/Timestamp..." dialog - new attribute "Recall on data access" added (e.g. for not local OneDrive files)
- Implemented: "Settings->File/folder list - Items color" - definig color for attribute "Recall on data access" is possible now

================================================================================
Important changes and bug fixes in the release 818
================================================================================

- Bug fix: Exception in "About" dialog - "Path info" button https://freecommander.com/forum/viewtopic.php?p=32354#p32354
- Bug fix: Keybord shortcuts problem introduced in the release 817 https://freecommander.com/forum/viewtopic.php?p=32350#p32350

================================================================================
Important changes and bug fixes in the release 817
================================================================================

- Bug fix: The defined 2nd shortcuts are not loaded after program restart  https://freecommander.com/forum/viewtopic.php?f=7&p=32203#p32203
- Bug fix: Internal viewer issues after clicking buttons to change view https://freecommander.com/forum/viewtopic.php?f=7&t=10379
- Bug fix: Deleting/copying a file from the desktop can throw an exception
- Bug fix: Opening ftp/sftp path from favorite folders tree broken
- Implemented: Search dialog - the quick view pane is restored when the form is opened
- Implemented: "Define action toolbars" dialog - defined custom symbols are now visible in the list
- Implemented: Thumbnail view for .wmf and .emf files
- Implemented: The visibility of the favorite toolbars is now per Layout definable
- Implemented: New item added to the tab context menu: Close all not locked folder tabs; If clicked with CTRL key - close not locked tabs in both panels
- Implemented: About dialog resizeable; More paths info added
- Implemented: Overwrite dialog for copy/move FreeCommander operation - rename in place is now possible

================================================================================
Important changes and bug fixes in the release 816
================================================================================

- Bug fix: Context menu function "Rename" partially broken
- bug fix: Toolbar separator - details definable: not properly implemented in some cases 

================================================================================
Important changes and bug fixes in the release 815
================================================================================

- Bug fix: Empty favorite toolbar will be shown if all toolbar items are defined as visible only in menu
- Bug fix: Auto refresh partially broken - introduced in 814
- Bug fix: Opened tree pane may slow down some operations 
- Implemented: Toolbar separator - details definable 

================================================================================
Important changes and bug fixes in the release 814
================================================================================

- Bug fix: Multirename form - tooltip always on top  https://freecommander.com/forum/viewtopic.php?f=7&p=31690#p31690
- Bug fix: Color issue in the setting dialog https://freecommander.com/forum/viewtopic.php?f=7&t=10328
- Bug fix: Tree pane - rename with F2 key is partially broken if the option "Allow rename on slow double click" is disabled https://freecommander.com/forum/viewtopic.php?f=7&p=31854#p31854
- Bug fix: Thumbnail of the text file is blurry if dark background is used https://freecommander.com/forum/viewtopic.php?f=7&t=10357
- Bug fix: Text thumbnails with unicode format broken   https://freecommander.com/forum/viewtopic.php?p=31867#p31867
- Bug fix: Deleting the item '..' from context menu may cause freezing  https://freecommander.com/forum/viewtopic.php?f=7&p=31895#p31895
- Bug fix: Plain view is not preserved after FC restart on left panel   https://freecommander.com/forum/viewtopic.php?p=31793#p31793
- Bug fix: Problem with text color of the active tab https://freecommander.com/forum/viewtopic.php?f=6&p=31915#p31915
- Implemented: "Tools -> Define keyboard shortcuts" - it is possible to define the second shortcut for each action
- Implemented: New column is posible "Relative path"
- Implemented: New columns category for pictures added: EXIF
- Implemented: Option available in the freecommander.ini file: TreeSortNodesType=X (0->like so far; 1->sort by path name; 2->sort by display name)
- Implemented: Quick filter accept '*.' for selecting items without dot
- Implemented: Compare folders - new option added "Ignore extension"
- Implemented: Search files/folders - menu item added "Edit -> Copyname without extension"
- Changed: Folder->Open focused->In the other pane (new Tab)/In the same pane (new Tab) - these functions are implemented now for several selected elements

================================================================================
Important changes and bug fixes in the release 813
================================================================================

- Bug fix: Customize favorite toolbars - Changing the order of the buttons has no effect if you add a separator https://freecommander.com/forum/viewtopic.php?f=7&t=10235 
- Bug fix: Rar archives cannot be opened if encryption for file names has been activated. Workaround - first open an archive without encryption.

- Implemented: "Tools -> Dos box" selecting the item with pressed SHIFT key opens the dos box as admin
- Implemented: Address bar toolbar - big icons allowed
- Implemented: New option for viewer - Use mouse wheel for: zooming/switching files 
- Implemented: New option to define in the [Form] section of the freecommander.ini - ThumbOpenAndSelectMode=1 ; 
               When this line is defined, a click on the symbol opens the file / folder and a click on the label selects the file / folder.
- Implemented: Context menu in viewer (images) - new item added "Save - overwrite without confirmation"                
- Changed: Long path support improved
- Changed: Address bar editing - spaces at the end of the path are removed now


================================================================================
Important changes and bug fixes in the release 812
================================================================================

- Bug fix: Attributes/Timestamp dialog - "Save/Load timestamp" function show empty message on "save"
- Bug fix: Define action toolbars - option "Show drop down arrow only" is broken 


================================================================================
Important changes and bug fixes in the release 811
================================================================================

- Bug fix: Search files/folders - The same file can exist several times in the result list if the search location is not correctly defined https://freecommander.com/forum/viewtopic.php?f=7&p=31283#p31283
- Bug fix: Search files/folders - cancellation of the deletion dialog is not handled correctly https://freecommander.com/forum/viewtopic.php?f=7&t=10173
- Bug fix: Search files/folders - file selection in the result list maybe wrong after deleting of some files from the list https://freecommander.com/forum/viewtopic.php?f=7&t=10174

- Implemented: Favorite tool button - new item added for context menu: Run - With "Run as" dialog
- Implemented: Define favorite tool - new placeholder parameter  %ActivItemNoExt% added 
- Implemented: Attributes/Timestamp dialog - "Save/Load timestamp" function added
- Implemented: Multirename - new EXIF property added: Focal length of lens in mm, Lens model name, Orientation of the camera


- Changed: Folder synchronize - comparison with only two options "Name" and "Size" is now possible. Until now comparison with only these two options always provided "?" as a result.
- Changed: The unit "kB" will be no more shown in the column "Size kB"

================================================================================
Important changes and bug fixes in the release 810a
================================================================================
- Bug fix: Exception when saving the settings if only one file pane is visible.


================================================================================
Important changes and bug fixes in the release 810
================================================================================
- Bug fix: Rename in the tree: DEL key want delete the renamed folder
- Bug fix: Option "Show drives as button bar - Use large icons" does not work if the option "Show drive bar per panel" is not active  


================================================================================
Important changes and bug fixes in the release 808
================================================================================

- Bug fix: Plain view is lost if used with quick filter on tab switch  https://freecommander.com/forum/viewtopic.php?f=7&t=10066
- Bug fix: Recycle Bin panel switch issue https://freecommander.com/forum/viewtopic.php?f=7&t=10070
- Bug fix: Recycle Bin refresh issue https://freecommander.com/forum/viewtopic.php?f=7&t=10071
- Bug fix: Quick viewer focus issue https://freecommander.com/forum/viewtopic.php?f=7&t=10073
- Bug fix: Sorting by Bit rate wrong https://freecommander.com/forum/viewtopic.php?f=7&t=10049

================================================================================
Important changes and bug fixes in the release 807
================================================================================

- Bug fix: Layout definition - the option 'Ignore main window size and position' will be unchecked if "Auto save current layout" is used.https://freecommander.com/forum/viewtopic.php?f=7&p=30814#p30814
- Bug fix: Multirename dialog - deleting a file in quick viewer doesn't remove it from the list  
- Bug fix: Search dialog - deleting a file in quick viewer doesn't remove it from the list  
- Bug fix: Some columns in the left panel may be empty on program start  (introduced in 806) https://freecommander.com/forum/viewtopic.php?p=30848#p30848
- Bug fix: Thumbnails view doesn't work with "Auto selectable views" + Plain view https://freecommander.com/forum/viewtopic.php?f=7&t=10000
- Bug fix: Plain view mode - deleteing a file from context menu doesn't remove it from the list  https://freecommander.com/forum/viewtopic.php?f=7&t=9972
- Bug fix: A slow double click on a folder in the tree view allows the renaming of the folder even though the option "Allow rename on slow double click" is not set
- Bug fix: "Keep expanded nodes per Tab": does not work when closing a tab https://freecommander.com/forum/viewtopic.php?f=19&t=10012
- Bug fix: Multi rename dialog, "Search for" field - the help after klick on "?" picture is wrong
- Bug fix: Adding a profile to a search filter doesn't immediately show paths https://freecommander.com/forum/viewtopic.php?f=7&t=10057
- Bug fix: Sorting by "Bit rate" may be wrong https://freecommander.com/forum/viewtopic.php?f=7&t=10049
- Bug fix: Lock view issue https://freecommander.com/forum/viewtopic.php?f=7&t=10041
- Bug fix: Auto selectable views - minor sorting issue https://freecommander.com/forum/viewtopic.php?f=7&t=9983
- BUg fix: Start Folder behavior changed https://freecommander.com/forum/viewtopic.php?f=7&t=10056
- Changed: Define columns dialog - default button changed from Cancel to OK https://freecommander.com/forum/viewtopic.php?f=7&t=10023

================================================================================
Important changes and bug fixes in the release 806
================================================================================
- Bug fix: Multirename in the release 805 broken. The changes are not written to disk. 

================================================================================
Important changes and bug fixes in the release 805
================================================================================

- Bug fix: Selecting files via commandline may not work for network paths https://freecommander.com/forum/viewtopic.php?f=7&p=30622#p30622 
- Bug fix: Deleting a file in the rename dialog from the context menu doesn't remove it from the list https://freecommander.com/forum/viewtopic.php?f=7&p=30631#p30631
- Bug fix: Deleting a file in the search dialog from the context menu doesn't remove it from the list
- Bug fix: Search dialog list - multiple items delete issue https://freecommander.com/forum/viewtopic.php?f=7&t=9909
- Bug fix: Sorting broken on delete https://freecommander.com/forum/viewtopic.php?f=7&t=9926
- Bug fix: Selecting files in "Synchronize" dialog broken https://freecommander.com/forum/viewtopic.php?f=7&t=9905

- Implemented: New action added - "Select all folders"
- Implemented: New action added - "Lock view ; Locks view and disable automatic views"
- Implemented: Search dialog - new option added: "Use big icons"
- Implemented: Multirename dialog - "Options->Select columns" added 
- Implemented: "Tools->Settings->Programs->Default action" - %InternalViewer%  can be used as program for default acion (double click; Enter key) 

================================================================================
Important changes and bug fixes in the release 804 
================================================================================

- Bug fix: Mouse double click may not work properly https://freecommander.com/forum/viewtopic.php?f=7&t=9879

================================================================================
Important changes and bug fixes in the release 803
================================================================================

- Bug fix: Release 802 does not run on Windows XP


================================================================================
Important changes and bug fixes in the release 802
================================================================================

- Bug fix: Scrolling in the details view is slower as in the previous version https://freecommander.com/forum/viewtopic.php?f=19&p=30356#p30356
- Bug fix: Sorting by any column in the search dialog changes the width of the columns https://freecommander.com/forum/viewtopic.php?f=7&p=30358#p30358
- Bug fix: Viewer - zoom with mouse wheel is broken
- Bug fix: Main menu minor issue https://freecommander.com/forum/viewtopic.php?f=7&t=9772
- Bug fix: Minor issue when using multi rename button/hotkey https://freecommander.com/forum/viewtopic.php?f=7&t=9789
- Bug fix: Create new folder tab from file container tab https://freecommander.com/forum/viewtopic.php?p=30437
- Changed: Drag&drop key modifier for move (favortite folders tree) changed from CTRL to SHIFT  https://freecommander.com/forum/viewtopic.php?f=7&t=9795
- Implemented: Option "Ignore diacritical marks" added (quick filter, quick search, filter, multirename)
- Implemented: New command line parameters: -LQF (left quick filter, e.g. -LQF=*.png ), -RQF (right quick filter) 
- Implemented: Multirename dialog - new command "Copy old name without extension" added
- Implemented: Multirename dialog - new option "Use big icons" added
- Implemented: Viewer, VLC Player - "Play loop" option added


================================================================================
Important changes and bug fixes in the release 801
================================================================================

- Bug fix: Filenames that start with periods (e.g.: .config) are not displayed correctly if the "Right align extension ..." option is active. 
- Bug fix: Toolbar buttons for List, Details, Thumbnails stay in down state if "Small icons" or "Large icons" is in menu selected 
- Bug fix: Rename of the volume drive does not work if rename operation with dialog is defined
- Bug fix: Search files - Find duplicate files may provide false result https://freecommander.com/forum/viewtopic.php?f=7&t=9669
- Bug fix: Search for files/folders does not work with ";" in path. Use " to enclose path with ";" https://freecommander.com/forum/viewtopic.php?f=7&t=9699
- Bug fix: Quick viewer close button does not work in multi rename dialog https://freecommander.com/forum/viewtopic.php?f=7&t=9707
- Bug fix: New added column profile is not visible on "Auto selectable views" tab https://freecommander.com/forum/viewtopic.php?f=6&t=9678
- Bug fix: Multi rename dialog - "Activate profiles combo box first" broken with quick view https://freecommander.com/forum/viewtopic.php?f=7&p=30211#p30211
- Bug fix: When using a toolbar button "Show main menu as popup menu" some submenus may not work (e.g. Color schemes, Favorite tools)
- Bug fix: Search files dialog - selecting files in the result list does not count selected (if Shift key is used) https://freecommander.com/forum/viewtopic.php?f=7&t=9717
- Bug fix: Favorite folder tree - drop on node with folder is broken
- Bug fix: Favorite folder dialog - active item color is unreadable https://freecommander.com/forum/viewtopic.php?f=7&t=9624 
- Bug fix: Chosen custom column profile "A" changes to custom profile "B" when a file is moved  https://freecommander.com/forum/viewtopic.php?p=30087#p30087
- Implemented: Protection against "right to left override" characters in the file name. https://krebsonsecurity.com/2011/09/right-to-left-override-aids-email-attacks/
- Implemented: Drop operation (while holding down the SHIFT key) on a Folder button in the Favorite toolbar works as "Move".
- Implemented: New condition for "Automatic views": <newtab>; if defined is always active 
- Implemented: Settings->Programs - define %AcceptOnlyFiles% as Parameter if you want to ignore the program start for folders 
- Implemented: "Alt+Left Click" on folder or archive file opens new tab in other pane
- Changed: Loading of the favorite tools faster when many favorite tools (more than 100) are defined.
- Changed: Item colors are no longer set in the background but directly while loading of the file list.

================================================================================
Important changes and bug fixes in the release 800
================================================================================
- Implemented: Multirename dialog - profiles sorted by name
- Implemented: Quick viewer - close button in the title bar added
- Implemented: Additional options for "Close all folder tabs": Close locked tabs too, Apply for both panels
- Implemented: Tab property dialog - icon definition is possible now 
- Implemented: Settings - new tab option "Use large images"
- Implemented: Setting for menu font size (Settings->View)
- Implemented: Search dialog - new options for searched text: As entered, Any term, All terms 
- Implemented: Search in file container
- Implemented: Quick filter field - with Ctrl+Enter apply quick filter for both panels
- Changed: Active option "Open folder with one click" opens the link to folder too
- Changed: Tab properties dialog - now the field 'Tab name' is always empty unless you define your own tab name.
- Changed: Address bar alow input of the file URI as suggested https://freecommander.com/forum/viewtopic.php?f=18&p=29991#p29991
- Bug fix: From version 793, thumbnail view is slower.
- Bug fix: Synchronize folders - the Quick Viewer does not follow the changes made to the selection in the file list.
- Bug fix: When using "Copy name without extension as text" to copy name of the folder with dot (e.g. aaa.bbbcccddd), only the first part is copied (e.g. aaa)

================================================================================
Important changes and bug fixes in the release 799
================================================================================
- Bug fix: Multirename on smartphone works again
- Changed: Buttons alignmet for left and right toolbar if buttons caption visible 
- Implemented: Search dialog - file editing from archive file is possible now
- Implemented: Background color of the file list in the search dialog changes if searching is active; line "BusyColor=" in freecommander.find.ini 
- Implemented: Multirename dialog - using substring (enclosed with \) for the option "Upper first letter following any of defined characters" is now possible
- Implemented: New command in multirename dialog added - "Copy old name"
- Implemented: New option for "File/folder list" added "Ignore size of link folder (reparse point)"; default value is false; https://freecommander.com/forum/viewtopic.php?f=6&p=29686&sid=ebcde0131eafec4ccc9ada14c4a8b621#p29686


================================================================================
Important changes and bug fixes in the release 798
================================================================================
- Implemented: Option to define in the freecommander.ini for deactivating of the color scheme in viewer - "ViewerUseColorScheme=0"
- Bug fix: Color scheme "MyDefaultColorSchema" does not deactivate color scheme in viewer

================================================================================
Important changes and bug fixes in the release 797
================================================================================
- Bug fix: Tree is not updated correctly after restart; https://freecommander.com/forum/viewtopic.php?f=7&t=9444
- Implemented: Now color scheme is used in Viewer and quick viewer
- Implemented: Two options in "Attributes/Timestamp" dialog added: 'Copy date "modified" to "created" for each file', 'Copy date "created" to "modified" for each file'
- Changed: Computing of folder Size - the size of the symbolic link folder is now always 0; https://freecommander.com/forum/viewtopic.php?f=6&p=29616#p29616 
 
================================================================================
Important changes and bug fixes in the release 796
================================================================================
- Bug fix: If the option "Quick filter bar always visible" is not active then exception appears on click in main menu

================================================================================
Important changes and bug fixes in the release 795
================================================================================
- Bug fix: Opening multiple files causes a crash  https://freecommander.com/forum/viewtopic.php?f=7&t=9317
- Implemented: Position of the settings dialog is saved
- Implemented: Unpacking the archive file from the desktop to another desktop folder is now possible.
- Implemented: New quick filter option added: Clear edit field when quick filter is deactivated
- Implemented: Color scheme menu icons can now be used https://freecommander.com/forum/viewtopic.php?f=20&t=9329  
- Implemented: Thanks to Dreamer for new color schemes: Solarized_Dark_Flat_by_Dreamer, Light_Beige_Flat_by_Dreamer; more color schemes https://freecommander.com/forum/viewtopic.php?f=18&t=8332
 
================================================================================
Important changes and bug fixes in the release 794
================================================================================
- Bug fix: Exception on program start if small icons used in the splitter toolbar

================================================================================
Important changes and bug fixes in the release 793
================================================================================
- Bug fix: Layout switching may cause the exception
- Bug fix: Program start fail on Windows 2003 https://freecommander.com/forum/viewtopic.php?f=19&p=29009#p29009
- Bug fix: Path change through DOS prompt writes the path to the address bar with trailing delimiter.
- Bug fix: After opening the zip file with the internal plugin fc_internal_zip, different unspecific exceptions can occur later.
- Changed: "Attributes/Timestamp..." dialog - "Copy Created -> Modified" changed as suggested https://freecommander.com/forum/viewtopic.php?f=7&t=9199#p29099
- Implemented: New action for main splitter added "Split 0/100 %" and "Split 100/0%" (Compatibility with old version)
- Implemented: JPG as screenshot format added 

================================================================================
Important changes and bug fixes in the release 792
================================================================================
- Bug fix: NC-Mode (sticky selection) with the active option "Select with right mouse button" - File selection under cursor is lost if using right mouse button for context menu 
- Bug fix: If thumbnail view is active before closing the program, then an error message will appear on the next startup
- Bug fix: No auto refresh after deleting file from smartphone
- Bug fix: Exception in internal viewer https://freecommander.com/forum/viewtopic.php?f=7&p=28890#p28890
- Bug fix: If the options "One tree per panel" and "Keep expanded nodes per tab" are active:  by switching between left and right pane - the expanded folders in the inactive tree are closed
- Implemented: New action "Set Quick Filter from clipboard"
- Implemented: New menu item "Edit -> Filter files with same ext." (Set quick filter to the extension of the focused item in the current panel )
- Implemented: Confirm overwrite dialog - file version info is showed now
- Implemented: Exif info in viewer - Context menu "Copy to clipboard" (selected lines)
- Implemented: Folder view in viewer - Context menu "Copy to clipboard" (selected text)
- Implemented: New option "Always open in new tab" for shell menu settings added 
- Implemented: "Redirect Win+E to FreeCommander" function opens the program in the foreground  
- Implemented: Create checksum - space characters are ignored in the field "Compare with the pattern sum"
- Implemented: "Make folder/file list..." now possible for archive files and SFTP folders
- Implemented: Thumbnails for epub files
- Changed: Multirename dialog - auto-completion disabled for date field
- Changed: Dos-Prompt field - auto-completion disabled 


================================================================================
Important changes and bug fixes in the release 788
================================================================================
- Bug fix: File/folder selection is lost when cancel delete operation (NC-Selection and "Use Freecommander" for delete)
- Bug fix: Screenshot in systems with multiple monitors and different resolutions is faulty.   
- Implemented: Viewer - new option for images added "Show frames" (in the context menu of the picture)
- Implemented: Quick filter option now available in the settings dialog "Also use for folder names"

================================================================================
Important changes and bug fixes in the release 787
================================================================================
- Bug fix: Multi rename option "Activate profiles combo box first" is broken https://freecommander.com/forum/viewtopic.php?f=7&t=9025
- Bug fix: Plain View does not remember selection after switching to another tab 
- Bug fix: Quick filter does not see some country-specific uppercase letters https://freecommander.com/forum/viewtopic.php?f=19&t=9022
- Bug fix: Drag&drop operation fails if it was started from plain view and some country-specific letters exist in the file name
- Bug fix: Color schemes saving is broken https://freecommander.com/forum/viewtopic.php?f=7&t=9054
- Bug fix: Folder synchronize (with compare by content) may stops after comparing the very last file 
- Implemented: Possibility to define text label in the favorite toolbar 
- Implemented: Search dialog - new option added "Open first profile on start"

================================================================================
Important changes and bug fixes in the release 786
================================================================================
- Bug fix: Copy&paste in the tree does not refresh the tree
- Bug fix: An internal error in the thumbnail display may slow down the display, especially from the network.

================================================================================
Important changes and bug fixes in the release 785
================================================================================
- Bug fix: Option "Keep expanded nodes per Tab" broken
- Bug fix: RAR files created on Android can not be extracted
- Bug fix: Column profiles - added Windows column can get wrong title
- Bug fix: Message "The system cannot find the path specified" can be showed twice https://freecommander.com/forum/viewtopic.php?f=7&t=9004
- Bug fix: Drive icons may be not correctly displayed in toolbars https://freecommander.com/forum/viewtopic.php?f=7&p=28430#p28430
- Changed: Tab caption - UNC-paths are displayed with "1:" instead of the server name https://freecommander.com/forum/viewtopic.php?f=7&t=7244
- Changed: Freecommander.ini option "ThumbsNoClipCaption" can be defined now in the settings dialog: "Draw caption without clipping" 
- Implemented: Search duplicates in archives
- Implemented: Multirename - new options for case processing "Upper first letter following any of defined characters:", "Keep current case"

================================================================================
Important changes and bug fixes in the release 784
================================================================================
- Bug fix: Rename with slow double click does not work if the option "Hot track only" is active
- Bug fix: Sorting on shell columns does not work properly
- Bug fix: Searching for the hex string does not work properly (viewer and search dialog)
- Bug fix: Copy to SFtp folder - "Overwrite older", "Overwrite smaller", "Auto rename target item" options does not work
- Implemented: Currently we can switch to the desired drive with Shift+drive-letter. If no root folder is active after switching, then using again Shift+drive-letter will switch to the root folder.
- Implemented: Quick starter settings - selection color added
- Implemented: Main menu items added "Edit -> Save selection" and "Edit -> Restore selection"
- Implemented: When navigating in the folder history (Alt + Left, Alt + Right), non-existent folders are ignored.
- Implemented: Searching duplicates 

================================================================================
Important changes and bug fixes in the release 783
================================================================================
- Bug fix: Exception on program start if thumbnail view is active in one pane
- Bug fix: Exception on drives reload if drive button was added to toolbar

================================================================================
Important changes and bug fixes in the release 782
================================================================================
- Bug fix: Quick starter - In order to search with quick filter first focus must be set in the field. That was not necessary in the old version.
- Bug fix: Automatic views - few minor bugs fixed https://freecommander.com/forum/viewtopic.php?f=7&t=8838
- Bug fix: Different behavior of selected items when deleting with the Windows method https://freecommander.com/forum/viewtopic.php?f=19&p=28073#p28073

================================================================================
Important changes and bug fixes in the release 781
================================================================================
- Bug fix: Compare folders - takes a long time if there are several thousand files in folders.
- Bug fix: Tree view is not updated when deleting a folder in the file list via context menu.
- Implemented: Quick starter settings - item colors by file type
- Implemented: Quick starter -  in "Repository -> Reorganize" function you will be asked, if non existing elements should be removed.
- Implemented: Switch view mode automatically on folder change - "Settings -> Column profiles/Automatic views"
- Implemented: If the favorite tree option "Full row select" is active, the double click (or click) will also work if the mouse is not over the name

================================================================================
Important changes and bug fixes in the release 777
================================================================================
- Bug fix: Internal viewer - the option "Enable adjust orientation" does not work correctly if "Show Exif" is switched on/off
- Bug fix: Main menu disappear if defined as "Show menu as toolbar" https://freecommander.com/forum/viewtopic.php?f=18&t=8715
- Bug fix: Queue button is always default for pack operation
- Implemented: Viewer settings - ignore list added
- Implemented: Action for reverse quick filter added
- Implemented: Layout option "Ignore main window size and position" now is defined per layout and not global https://freecommander.com/forum/viewtopic.php?f=18&t=8369
- Implemented: "Settings - Shell menu" new option added "Apply to: Current user, All users"
- Implemented: Quick starter - quick filter field use the settings color now
- Implemented: New action added - Close duplicate Tabs
- Implemented: "Define favorite toolbars" dialog - "Duplicate" function added; Drag&drop for moving to another toolbar 

================================================================================
Important changes and bug fixes in the release 776
================================================================================
- Bug fix: Quick filter - exclude multiple extensions does not work https://freecommander.com/forum/viewtopic.php?f=7&t=8654
- Bug fix: Building of the zip file name broken https://freecommander.com/forum/viewtopic.php?f=7&t=8662
- Implemented: Quick filter field - select all with Ctrl+A is now possible https://freecommander.com/forum/viewtopic.php?f=7&t=8612
- Implemented: New action added "Copy name without extension as text"
- Implemented: Delete operation (Windows) non blocking now
- Changed: Quick starter repository files now saved in UTF8 format


================================================================================
Important changes and bug fixes in the release 775
================================================================================
- Bug fix: Zip naming issue http://forum.freecommander.com/viewtopic.php?f=7&t=8596
- Bug fix: Search function - size filter is ignored sometimes https://freecommander.com/forum/viewtopic.php?f=7&t=8650
- Bug fix: View of the PDF files does not work for some installed PDF programs
- Implemented: Quick filter popup menu - new item added: Clear edit field
- Implemented: Quick filter - click on quick filter button with pressed CTRL key: edit field will be cleared 
- Implemented: Quick starter - context menu for the line added
- Implemented: Version checker form - frequency of checking can be set here too
- Implemented: Basic functions for SFTP client (use first with test data!)

================================================================================
Important changes and bug fixes in the release 774
================================================================================
-Bug fix: Rename on smartphons broken for current Windows 10
-Bug fix: Some tab icons are not displayed correctly http://forum.freecommander.com/viewtopic.php?f=7&t=8545
-Bug fix: Refresh of 'Network' goes to 'Desktop' http://forum.freecommander.com/viewtopic.php?f=7&t=8530
-Bug fix: When using Linked browsing and quick view for both panels, item in the file list (inactive panel) is updated, but quick view for inactive panel is not updated. http://forum.freecommander.com/viewtopic.php?f=6&t=8583
-Implemented: Column profile definition - new option added: 'All subfolder levels for columns:  Files, Items, Folders'
-Implemented: Internal viewer - basic functions for image editing added
-Implemented: Favorite tools - if folder is defined as favorite tool, than parameters %RightDir%, %LeftDir%, %InactivDir% can be used if you want to open the folder not in the active pane

================================================================================
Important changes and bug fixes in the release 773
================================================================================
- Bug fix: Drive buttons in toolbar have no icons on program start
- Bug fix: If the Explorer option "Hide extensions for known types" is active, then files can not be deleted from the desktop (FC Method).
- Bug fix: Command line does not work if current tab is ::Computer http://forum.freecommander.com/viewtopic.php?f=7&t=8518#p27282
- Bug fix: Unpacking multiple archive files at once - if the destination path is empty, the folder of the first file will always be used as destination. http://forum.freecommander.com/viewtopic.php?f=6&t=8515
- Bug fix: Viewer - searching in hex mode does not work for properly
- Bug fix: "Make folder/file list.."  dialog - selected predefined filter is ignored
- Bug fix: Auto save settings broken
- Implemented: NOT operator for quick filter: \~
- Implemented: Multirename - pattern for parent folder (level 1 to 9) added
- Implemented: "Customize action toolbars" dialog - quick filter added

================================================================================
Important changes and bug fixes in the release 772
================================================================================
- Bug fix: Drag&Drop in thumbnail view broken in 771
- Bug fix: Search dialog - "Attribute/Timestamp..." dialog can not be opened
- Bug fix: Full path is showed for  "Network shortcut" http://forum.freecommander.com/viewtopic.php?f=19&t=8432 
- Bug fix: Define toolbar items dialog - dialog is opened for the false item if the list of toolbar items was scrolled. http://forum.freecommander.com/viewtopic.php?f=7&t=8496
- Changed: The drop-down menu for the Desktop button in the toolbar has been changed. Now no submenus are loaded. This avoids delays in starting of the program.
- Implemented: Option for search dialog to define in the section [fcSearchForm] of the file FreeCommander.find.ini:   OpenLocationChangeShortcut=1 if the shortcut should be changed from Ctrl+Space to Alt+Space
- Implemented: New action added "Collapse all nodes, except selected node, in the tree view"
- Implemented: Admin plugin for locking some functions of the program


================================================================================
Important changes and bug fixes in the release 771
================================================================================
- Bug fix: "Check for updates" drop list items are duplicated after changing of the language http://www.forum.freecommander.com/viewtopic.php?f=7&t=8428
- Bug fix: Possible exception if editing viewer settings from general settings dialog
- Changed: "Color schema" changed to "Color scheme"
- Changed: Hotkeys (Ctrl+Up, Ctrl+Down) for changing search result splitter changed to Alt+Down, Alt+Up http://www.forum.freecommander.com/viewtopic.php?f=7&t=8446
- Changed: Handling of the favorites LNK files changed. Now target path will be handled.  
-Implemented: New option in copy dialog "Use last overwrite options"
-Implemented: New drag&drop option "Start dragging on label or icon only"

================================================================================
Important changes and bug fixes in the release 768
================================================================================

- Bug fix: Quick filter option (only in freecommander.ini) "QuickFilterFolderNamesToo" broken if set to "0"
- Bug fix: The size of the tree pane may be wrong after program restart http://www.forum.freecommander.com/viewtopic.php?f=7&t=8389
- Bug fix: Start minimize option broken
- Bug fix: Color for hot (focused and selected) item may be wrong http://www.forum.freecommander.com/viewtopic.php?f=7&t=8338

================================================================================
Important changes and bug fixes in the release 767
================================================================================

- Bug fix: "Folder - > Synchronize..." same files can be marked as unresolved
- Bug fix: Check for updates on Windows XP fail
- Bug fix: Filter in the plain view can fail 

================================================================================
Important changes and bug fixes in the release 766
================================================================================
- Bug fix: Possible exception in the search dialog when quick view is switched off.
- Implemented: Option to define in the [Form] section of the freecommander.ini: LayoutsIgnoreMainWindowSize; 1 - in layout saved window size is ignored; 0 - in layout saved window size is used 
- Implemented: "Check for update" option defined under Tools->Settings->General

================================================================================
Important changes and bug fixes in the release 765
================================================================================
- Bug fix: Favorite tool shortcut for changing location fail in some cases http://forum.freecommander.com/viewtopic.php?f=19&t=8318
- Bug fix: Switching from layout with one pane to layout with two panes fail http://forum.freecommander.com/viewtopic.php?f=7&t=8348
- Bug fix: Copy file from the disk folder to the smartphone card with Shift+F5 fail - copied file ends up in desktop folder. 

================================================================================
Important changes and bug fixes in the release 764
================================================================================
- Bug fix: Exception on program start if "Show drives as popup button" option is used
- Bug fix: Tree may be not visible http://www.forum.freecommander.com/viewtopic.php?f=7&t=8333

================================================================================
Important changes and bug fixes in the release 763
================================================================================
- Bug fix: Errors may appears if open multiple files simultaneously (with Enter key) http://www.forum.freecommander.com/viewtopic.php?f=7&t=7863#p26390
- Implemented: Font color for quick filter
- Implemented: "Only border" option added for "Focused item inactive list"
- Implemented: Restore last used color schema
- Implemented: Color schemas saved in settings backup 
- Implemented: "Exposure time" added to EXIF info (multirename and status row)
- Implemented: New options for the tree added: "Full rows select", "Theme off"
- Changed: Menu "Tools -> View style" moved to "View -> View style" 

================================================================================
Important changes and bug fixes in the release 762
================================================================================

- Bug fix: Error message "No colors..." on program start if starting with saved layout http://www.forum.freecommander.com/viewtopic.php?f=7&t=8223
- Bug fix: Color schema adds color by file type http://www.forum.freecommander.com/viewtopic.php?f=7&t=8241
- Implemented: Custom style dialog - definition for menu added
- Implemented: "Settings -> Folder Tabs" more colors for tabs added

================================================================================
Important changes and bug fixes in the release 761
================================================================================

- Bug fix: Renaming operation may fail for some languages http://www.forum.freecommander.com/viewtopic.php?f=7&t=8204
- Bug fix: Exception on program start if last used view was "Thumbnails"
- Implemented: Color schema can be saved and restored View->Color schemas
- Implemented: Color schema can be saved with layout too
- Implemented: Loading drive icons in background - program start may be faster

================================================================================
Important changes and bug fixes in the release 760 compared to 740
================================================================================

- Bug fix: Some russian chars does not work in quick search http://www.forum.freecommander.com/viewtopic.php?f=7&t=7750
- Bug fix: '\&' operator in quick filter does not work 
- Bug fix: Using ENTER while editing the options in "Settings -> Programs" closes the entire dialog http://www.forum.freecommander.com/viewtopic.php?f=19&t=7740
- Bug fix: View->Swap function may cause exception
- Bug fix: Favorite tool icon is not visible if favorite tool is integrated in splitter toolbar
- Bug fix: "Windows preview" icon is not created in the default viewer toolbar
- Bug fix: Using ENTER while editing the options in "Column Profiles" or "Status Bar" closes the entire dialog  http://www.forum.freecommander.com/viewtopic.php?p=25041#p25041
- Bug fix: Selection problem if extension not showed in the Name column http://www.forum.freecommander.com/viewtopic.php?f=19&t=7231
- Bug fix: Wrong file highlighting when NC-style selection is enabled http://www.forum.freecommander.com/viewtopic.php?f=19&t=7810
- Bug fix: Selection duplicated in other tabs http://www.forum.freecommander.com/viewtopic.php?f=19&t=7809
- Bug fix: Favorites command "Open all in tabs" may fail http://www.forum.freecommander.com/viewtopic.php?f=19&t=7797
- Bug fix: Plain view - Opening multiple selected files does not always work http://www.forum.freecommander.com/viewtopic.php?f=7&t=5887 
- Bug fix: Program may crash if base folder tree is set to drive and a DVD drive without disk will be selected
- Bug fix: Column profiles "File container <cart>" issue http://www.forum.freecommander.com/viewtopic.php?f=7&t=7848
- Bug fix: Open default program broken http://www.forum.freecommander.com/viewtopic.php?f=7&t=7859
- Bug fix: Copy files from nested archive broken 
- Bug fix: Loading the toolbar icons at the program start can lead to the endless loop.
- Bug fix: Searching for Zero Byte Files does not work http://www.forum.freecommander.com/viewtopic.php?f=18&t=7869
- Bug fix: After deleting the last element in the list, the cursor jumps to the first element http://www.forum.freecommander.com/viewtopic.php?f=7&t=7851
- Bug fix: Current folder is not used if perform default action http://www.forum.freecommander.com/viewtopic.php?f=7&t=7882
- Bug fix: Prefered sort direction (column definition in the detail view) is not used if sorting started with toolbar button or shortcut http://www.forum.freecommander.com/viewtopic.php?f=7&t=7899
- Bug fix: Quick viewer - wrong panel focused http://www.forum.freecommander.com/viewtopic.php?f=7&t=7894
- Bug fix: Quick viewer zoom state lost http://www.forum.freecommander.com/viewtopic.php?f=7&t=7893
- Bug fix: Quick viewer does not show file if already open on program start 
- Bug fix: Font color for quick starter is not used
- Bug fix: Maximized start is not possible if the option "Handle closing as minimization" is active
- Bug fix: File container favorite does not open at container contents http://www.forum.freecommander.com/viewtopic.php?f=19&t=7979  
- Bug fix: Locked path of MTP device is lost when device is not connected http://www.forum.freecommander.com/viewtopic.php?f=19&t=7968
- Bug fix: Second favorites sets' items cannot be opened from pulldown http://www.forum.freecommander.com/viewtopic.php?f=7&t=7986
- Bug fix: It is possible to define duplicate keyboard shortcut http://www.forum.freecommander.com/viewtopic.php?f=7&t=7966
- Bug fix: Tree option "Show Windows archive files" broken 
- Bug fix: Search history is not always saved http://www.forum.freecommander.com/viewtopic.php?f=19&t=7995
- Bug fix: Exception in Folder Synchronize dialog if 'Empty folders' option is active
- Bug fix: FTP is not case sensitive
- Bug fix: "Use Vista+ delete method" option broken on Windows 10 http://www.forum.freecommander.com/viewtopic.php?f=7&t=8101
- Bug fix: Using of the large icons in the favorite toolbar broken http://www.forum.freecommander.com/viewtopic.php?f=6&t=8116
- Bug fix: "Go To Folder" history always empty http://www.forum.freecommander.com/viewtopic.php?f=7&t=8114
- Bug fix: The width of the tree pane is not correctly restored on start
- Bug fix: Folder size can be not correctly if contains files > 4 GB
- Bug fix: Multirename not working when making consecutive rename operations http://www.forum.freecommander.com/viewtopic.php?f=7&t=8019
- Bug fix: Synchronize folder dialog - filter fields does not accept space character

- Changed: Multirename - negative value for counter "Start at" allowed again   
- Changed: Select item options: "By click on extension..." and "By click on item icon" now separated for Windows-mode and NC-mode
- Changed: Color by attributes - now any set of attributes is possible
- Changed: Copy/Paste operation is now performed asynchronously (set CopyPasteInThread=0 for old behavior)
- Changed: Font color is not changed now if "Only border" for focused item is active in NC-Mode http://www.forum.freecommander.com/viewtopic.php?f=6&t=7853
- Changed: "Define filter" dialog - option for "Older than" added 
- Changed: Temporary filter in "Set filter" dialog extended by condition for date modified 
- Changed: Due to a bug in Windows 10 1607 the operations on portable devices was broken. 
	 The internal treatment of these devices has been revised. Now the basic functions works with the portable devices (from Windows 7). 
- Changed: Better performace for copy operation in network (FreeCommander method)

- Implemented: Report missing files for "Verify MD5-checksums"  http://www.forum.freecommander.com/viewtopic.php?f=19&t=7755   
- Implemented: New system tree option for excluding some nodes from the tree 
- Implemented: Status bar - File Container filter http://www.forum.freecommander.com/viewtopic.php?f=20&t=7847
- Implemented: Split file command
- Implemented: Combine files command
- Implemented: Action toolbar for the left and right border of the main window
- Implemented: New thumbnail option "No thumbnails for the files:"
- Implemented: Option "Color by attributes" extended to "Color by attributes and timestamp"
- Implemented: New property "Font color" added for favorite folder 
- Implemented: In viewer: Multiframe images (tiff, ico, avi), EXIF info can be showed, Saving images in many formats (popup menu), Print preview for images (popup menu)
- Implemented: Search dialog - time interval filter accept multiplier now; e.g. |day*4, |hour*2, |month*3, -|week*5, -|year*2
- Implemented: The width of the input dialog (e.g. for new folder F7) is changeable now
- Implemented: VLC media player (videolan.org) integrated in viewer and quick viewer 
- Implemented: Checksum dialog - new sum methods added (SHA1, SHA2)
- Implemented: Completion of renaming operation with TAB key opens the next item ready for renaming 


================================================================================
Important changes and bug fixes in the release 740 compared to 715
================================================================================
    - Bug fix: Search profile doesn't retain Timestamp "Not older option" forum.freecommander.com/viewtopic.php?f=7&t=7108
    - Bug fix: Main window is always hidden if starting FreeCommander with the options "Minimize to system tray" and "Start minimized"
    - Bug fix: '[' and ']' does not works in quick filter
    - Bug fix: Invert selection - the first element of the list is not selected if no parent folder '..' is visible in the file list
    - Bug fix: The column titles may be not translated if the option "Start minimized" is active
    - Bug fix: Locked tab "D:\My Folder" with "Navigation to subfolders" - navigation is possible to "D:\My Folder is locked"
    - Bug fix: "Save container to file..." broken forum.freecommander.com/viewtopic.php?f=7&t=7160
    - Bug fix: On some PCs all timestamps shows as 1899.12.30 00:00 forum.freecommander.com/viewtopic.php?f=7&t=7197#p23091
    - Bug fix: Active layout is not checked in menu if more as 10 layouts defined
    - Bug fix: Settings->General "Start minimized" option broken
    - Bug fix: Selection problem fixed forum.freecommander.com/viewtopic.php?f=7&t=7073
    - Bug fix: Checked state is initial not visible on splitter button forum.freecommander.com/viewtopic.php?f=19&t=7249
    - Bug fix: FTP connections are not listed if connection name has special chacter (e.g. German ö,ä,ü,...)
    - Bug fix: When changing folders in network shares, when you go back one level up, the cursor jumps to the top forum.freecommander.com/viewtopic.php?f=19&t=7270
    - Bug fix: Drop folder to Deskop button - the content of the folder is dropped but not the folder self
    - Bug fix: Customized button caption (toolbar buttons) is ignored for layouts and favorites forum.freecommander.com/viewtopic.php?f=6&t=7282
    - Bug fix: Splitter position is not restored after hiding/opening inactive panel (F10) forum.freecommander.com/viewtopic.php?f=19&t=7292
    - Bug fix: The state of "go to the next history item" toolbar botton is not changed forum.freecommander.com/viewtopic.php?f=19&t=7291
    - Bug fix: Item list Icons do not follow Item list Names upon change of sort type forum.freecommander.com/viewtopic.php?f=19&t=7317
    - Bug fix: Actions "Set active panel to X%" broken
    - Bug fix: Plain views icons do not toggle when in address bar forum.freecommander.com/viewtopic.php?f=7&t=7345
    - Bug fix: Selection in NC-Mode broken forum.freecommander.com/viewtopic.php?f=6&t=7390
    - Bug fix: Folder size consolidation toggle ("KB") unpredictable state forum.freecommander.com/viewtopic.php?f=19&t=7080
    - Bug fix: Del key issue with rename in "Favorites - edit..." forum.freecommander.com/viewtopic.php?f=7&t=7408
    - Bug fix: Search result: Open location shortcut changed to original value - Space (Shift+Space supported too) forum.freecommander.com/viewtopic.php?f=6&t=7400
    - Bug fix: Linked browsing broken on the way "up" forum.freecommander.com/viewtopic.php?f=7&t=7410
    - Bug fix: The main window opens on the primary monitor although closed on the second monitor - only if maximized
    - Bug fix: Folder synchronize problems forum.freecommander.com/viewtopic.php?f=7&t=7445
    - Bug fix: Unwanted selection in NC-Mode forum.freecommander.com/viewtopic.php?f=7&t=7362
    - Bug fix: "Auto add wildcards" option in quick filter is broken forum.freecommander.com/viewtopic.php?f=7&t=7360
    - Bug fix: New folder should allow path with more than one directory forum.freecommander.com/viewtopic.php?f=20&t=6969
    - Bug fix: "Quick viewer size by file type" option broken for jpg files
    - Bug fix: Thumbnails may be false if using refresh function or if switching tabs with thumbnails view
    - Bug fix: Multirename dialog - not correctly displayed for bigger fonts (150%) if profiles defined
    - Bug fix: Compare folders is broken if UNC path is used
    - Bug fix: Toolbar position is not saved if using "Tools->Save settings"
    - Bug fix: Wrong tab order in "Define favorite toolbars" dialog forum.freecommander.com/viewtopic.php?f=7&t=7499
    - Bug fix: Delete button not working in Laouts edit dialog forum.freecommander.com/viewtopic.php?f=7&t=7500
    - Bug fix: Maximized/normal state of the main window not correctly restored in layouts forum.freecommander.com/viewtopic.php?f=7&t=7496
    - Bug fix: Popup menu is not showing by drop on address bar although the setting for showing popup menu is active forum.freecommander.com/viewtopic.php?f=19&t=7507
    - Bug fix: Show/hide main menu in the status bar context menu doesn't work always forum.freecommander.com/viewtopic.php?f=7&t=7518
    - Bug fix: Exception on closing of the layout dialog forum.freecommander.com/viewtopic.php?f=7&t=7497
    - Bug fix: Incorrect file name suggested in Pack files dialog forum.freecommander.com/viewtopic.php?f=7&t=7204
    - Bug fix: Favorites set dialog - rename does not work
    - Bug fix: FTP - set timestamp for the uploaded file does not work
    - Bug fix: File container - many problems solved forum.freecommander.com/viewtopic.php?f=6&t=7549
    - Bug fix: Tree position is not correct restored when "Show menu as toolbar" active is (only if main window is maximized)
    - Bug fix: Tree is not refreshed if context menu delete command is used
    - Bug fix: View option for favorite folder does not work always http://www.forum.freecommander.com/viewtopic.php?p=24465#p24465 
    - Bug fix: Toggle betwwen current and thumbnail view (Ctrl+I) does not work properly if folder was changed http://www.forum.freecommander.com/viewtopic.php?f=7&t=7609
    - Bug fix: Exception if you try to open folder in the file container but the folder does not exist http://www.forum.freecommander.com/viewtopic.php?p=24456#p24456
    - Bug fix: Quick viewer resize problem if "top" is used for "Align in panel"  http://www.forum.freecommander.com/viewtopic.php?f=7&t=7641
    - Bug fix: Exception on some PCs, e.g. on usb drive add/remove (introduced in 731)
    - Bug fix: Deleting the folder in the tree causes error messages http://www.forum.freecommander.com/viewtopic.php?p=24730#p24730 
    - Bug fix: File names may be not fully visible on high DPI screen http://www.forum.freecommander.com/viewtopic.php?f=7&t=7622
    - Bug fix: Command line option "-Layout=" does not work if one instance option is active
    - Bug fix: Color items by predefined filter does not work properly http://www.forum.freecommander.com/viewtopic.php?f=19&t=7727

    - Implemented: It is possible now to add: Layouts, Favorite tools, Favorites and Drives to action toolbars. Only items with assigned shortcut works in action toolbar.
    - Implemented: New method Copy/Move operation performed by FC added (Vista+ only)
    - Implemeneted: New tree option "Keep expanded nodes if tree per Tab"
    - Implemented: Sorting by Windows columns improved ("Data type" added to the column definition )
    - Implemented: Elevation prompt (admin rights) will be showed for unpack operation if needed
    - Implemented: New Option in search dialog - Run in external process
    - Implemented: Middle button click on favorite item in toolbar opens favorite target folder in new tab forum.freecommander.com/viewtopic.php?f=20&t=7174
    - Implemented: Delete operation improved; option "Use Vista+ delete method" added
    - Implemented: Loading of network shares improved forum.freecommander.com/viewtopic.php?f=6&t=6288
    - Implemented: New command line option added -StartMinimized
    - Implemented: Address bar edit field - accept button added
    - Implemented: FTP - unicode support added forum.freecommander.com/viewtopic.php?f=7&t=7041
    - Implemented: New option in the search form - Use left/right for "Open location"
    - Implemented: Attributes/Timestamp dialog - new options for "Set timestamp as in target folder" added: "Created from Modified" and "Modified from Created"
    - Implemented: Favorite items edit dialog - shortcuts for rename, delete, up, down added
    - Implemented: Icons for favorite tools now loaded in background (important for not existend or slow network paths )
    - Implemented: Click on button with the folder in the favorite tools toolbar - added Ctrl+Click (open folder in new tab), Alt+Click (open folder in the opposite pane), Ctrl+Alt+Click (open folder in new tab in the opposite pane)
    - Implemented: Click on folder in the favorite folders tree - added Ctrl+Click (open folder in new tab), Alt+Click (open folder in the opposite pane), Ctrl+Alt+Click (open folder in new tab in the opposite pane)
    - Implemented: Click on folder in system folder popup menu - added Ctrl+Click (open folder in new tab) forum.freecommander.com/viewtopic.php?f=6&t=7283
    - Implemented: New options for "Select with mouse pointer" added - Action by click on free space in label, action by click on item icon (these options was till now available only in freecommander.ini )
    - Implemented: Left click in the free area of the address bar start the editing if the option "Show history popup menu on free area click" is not set
    - Implemented: Additional option for auto size of the 'Name' column - Fill remaining space
    - Implemented: Operations queue for operations ("Use FreeCommander" operations)
    - Implemented: New action added "Paste address from clipboard and reload" Shift+Alt+G
    - Implemented: Main menu item added Edit->Address bar
    - Implemented: Mouse "Snap to" implemented
    - Implemented: Searching in the office files (docx, xlsx, odt)
    - Implemented: Option to set in the freecommander.ini: CopyFullPath_AddLastDelimiter=0 - set the value to 1 if you want to add trailing backslash if copy folder paths to clipboard
    - Implemented: New action added "Toggle toolbars visibility"
    - Implemented: Favorite folder sets
    - Implemented: New option added "Always perform copy operation for left button drag&drop"
    - Implemented: Last position of the layout dialog will be saved
    - Implemented: Doubleclick on the line in the layout dialog perform "Apply" command
    - Implemented: 'Settings->Shell Menu' - options for adding "Open with Freecommander" item to shell context menu
    - Implemented: New option "Show basket icon" for splitter toolbar added 
    - Implemented: New command line option added (set active panel to left/top or right/bottom) "-Panel=L" or "-Panel=R"
    - Implemented: New thumbnail size added (512)
    

    - Changed: Last selected layout is marked as checked (till now - only if "Auto save current layot" was active)
    - Changed: Deley befor opening of the rename dialog removed forum.freecommander.com/viewtopic.php?f=6&t=7287
    - Changed: Multirename - mouse scrolling in the fields is allowed now only if the mouse cursor is in the filed forum.freecommander.com/viewtopic.php?f=19&t=7301
    - Changed: Settings dialog - OK, Cancel, Apply buttons moved to the right site of the dialog forum.freecommander.com/viewtopic.php?f=20&t=7421
    - Changed: Quick search support special characters forum.freecommander.com/viewtopic.php?f=7&t=7414
    - Changed: Splitter toolbar should be visible if hot spot buttons are used forum.freecommander.com/viewtopic.php?f=20&t=7516
    - Changed: Mouse wheel scroll for details view follows now Windows settings
    - Changed: Click on basket icon in splitter loads the Bin Tray in the active panel
    - Changed: Subfolder filter in search dialog simplified
    - Changed: Modifications for high resolution screens
    - Changed: Suppress message when global shortcut can not be registered (only if second or further program instance is started)   
    - Changed: Redirect Win+E to FreeCommander now permanent and not only per sesion

Full history you can find here http://www.forum.freecommander.com/viewtopic.php?f=6&t=775&start=165


            
